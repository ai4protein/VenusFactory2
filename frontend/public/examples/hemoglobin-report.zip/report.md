# Hemoglobin subunit alpha

Eight specialist research assignments; 6 chapters passed completion checks.

## Contents

1. Identity, sequence & evolution

2. Function, catalysis & pathways

3. Structure, dynamics & ligand binding

4. Interactions, expression & regulation

5. Variants, modifications & phenotypes

6. Biophysics, expression & production

7. Protein engineering & design

8. Datasets, applications & reproducibility

## 1. Identity, sequence & evolution

### Identity, Sequence & Evolution of Human Hemoglobin Subunit Alpha (P69905)

### Gene Identity and Genomic Context

Human hemoglobin subunit alpha is encoded by two paralogous genes, **HBA1** and **HBA2**, both located in the alpha-globin cluster on chromosome 16 (S1). These two genes arose from a relatively recent duplication event and encode identical mature proteins. The UniProt entry P69905 is shared by both gene products, reflecting their sequence identity at the protein level. This duplication is clinically significant: alpha-thalassemia commonly results from deletions affecting one or both genes, and the presence of two copies per chromosome (four total in diploid cells) explains the dosage-dependent phenotype spectrum described in the disease annotation (S1). A structural variant deletion covering HBA1/HBA2/HBM/HBQ1 has been associated with nine blood metabolic traits, most strongly mean corpuscular volume (β = −0.570, p = 1.22 × 10⁻⁹¹), illustrating the phenotypic impact of losing multiple alpha-like globin genes (S14).

The two genes are differentially expressed at the mRNA level, with HBA2 typically producing more transcript than HBA1. A 2026 study using peripheral blood mRNA established that the peak area ratio of HBA2 to HBA1 (PAR1) can identify common gross-deletion types and predict non-coding-region mutations in HBB, demonstrating that quantitative expression differences between the paralogs have diagnostic utility (S8). Additionally, regulatory variants in the HBA1 3'UTR can cause alpha-thalassemia: a novel insertion (HBA1:c.*119_120insT) and a missense variant (HBA1:c.*150C>A) were identified in patients with persistent microcytosis, with in silico analyses suggesting disruption of RNA secondary structure, impaired interactions with HuR and AUF1, and altered microRNA binding (e.g., miR-16-5p) (S9).

### Protein Sequence and Mature-Chain Numbering

The precursor protein is 142 amino acids long. The initiator methionine (position 1) is removed co-translationally, as demonstrated by multiple experimental studies (PubMed 12665801, 13872627, 13954546, 14093912; S1). The mature hemoglobin subunit alpha chain therefore spans residues **2–142**, comprising 141 amino acids. This mature chain is the form found in circulating hemoglobin tetramers. The UniProt feature annotation designates the chain as "Hemoglobin subunit alpha" (PRO_0000052653) spanning positions 2–142, with the initiator methionine annotated as "Removed" (S1).

An important exception exists: in the rare Thionville variant, the initiator methionine is not cleaved and instead becomes acetylated, producing a longer alpha-globin chain (S1, PTM comment). This illustrates that the N-terminal processing is not absolute and can be altered by sequence context in variants.

The mature chain contains a proteolytically derived bioactive peptide, **hemopressin**, corresponding to residues 96–104 of the mature chain numbering (S1). Hemopressin acts as an antagonist of cannabinoid receptor CNR1, blocking its signaling (PubMed 18077343; S1). This peptide is released from hemoglobin alpha and represents a functional moonlighting product of the globin sequence.

### Sequence Composition and Physicochemical Properties

ProtParam calculations on the 142-residue precursor (including Met1) yield a molecular weight of 15,257.36 Da and a theoretical pI of 8.717 (S22). The protein is basic, consistent with its high content of histidine (10 residues) and lysine (11 residues) relative to acidic residues (8 Asp + 4 Glu). The GRAVY score is 0.0479, indicating a slightly hydrophobic protein overall, typical of a globular oxygen carrier that must accommodate a hydrophobic heme pocket. The instability index heuristic is 6.974, predicting high stability in solution, consistent with the well-known robustness of hemoglobin. Aromaticity is 0.0775, reflecting 7 Phe, 3 Tyr, and 1 Trp residues.

The amino acid composition is notable for the complete absence of isoleucine (Ile = 0), a rare feature among globins. The single cysteine (position 104 in mature numbering, Cys104) is conserved in many hemoglobins and can participate in redox chemistry. The 10 histidines include the proximal (His87, position 88 in precursor numbering per UniProt binding site annotation) and distal (His58) residues that coordinate the heme iron and oxygen, respectively (S1).

### Domain Architecture and Functional Sites

InterPro analysis identifies six entries for P69905 (S24):

1. **IPR000971 Globin** (domain): residues 2–142, with member databases Pfam PF00042 and PROSITE profile PS01033. Associated GO terms include heme binding (GO:0020037).
2. **IPR002338 Hemoglobin, alpha-type** (family): residues 3–142, with CDD cd08927 and PRINTS PR00612. Associated GO terms include heme binding, oxygen transport (GO:0015671), and hemoglobin complex (GO:0005833).
3. **IPR002339 Hemoglobin, pi** (family): four discontinuous fragments (4–29, 49–58, 73–83, 105–116), representing the helical regions that form the globin fold. Associated GO terms include iron ion binding (GO:0005506) and oxygen binding (GO:0019825).
4. **IPR009050 Globin-like superfamily**: residues 1–142 (full precursor), based on SCOP superfamily SSF46458.
5. **IPR012292 Globin/Protoglobin** (homologous superfamily): residues 2–142, based on CATH G3DSA:1.10.490.10.
6. **IPR050056 Hemoglobin and related oxygen transporters** (family): residues 1–142, based on PANTHER PTHR11442.

The globin domain spans the entire mature chain (residues 2–142), consistent with the canonical 3-on-3 alpha-helical globin fold. The "Hemoglobin, pi" family fragments correspond to the helical segments (A, B, E, G helices in globin nomenclature), reflecting the discontinuous nature of the conserved fold when detected by PRINTS motifs.

UniProt annotates two key binding sites (S1):
- **His58** (precursor numbering; position 57 in mature chain): binds O₂ (ChEBI:15379), based on PROSITE-ProRule PRU00238.
- **His88** (precursor numbering; position 87 in mature chain): proximal binding residue for heme b iron (ChEBI:60344, ChEBI:18248), based on the same rule.

These histidines are the canonical distal and proximal histidines of the globin fold, absolutely conserved across vertebrate hemoglobins and myoglobins.

### Post-Translational Modifications and Processing Sites

The mature protein undergoes several post-translational modifications (S1):
- **Phosphorylation** at Ser4 (position 4 in precursor numbering; Ser3 in mature chain), detected experimentally (PubMed 24275569).
- **N6-succinyllysine** at Lys8 (alternate modification), inferred from the orthologous mouse hemoglobin alpha (UniProt P01942) by sequence similarity (ECO:0000250).
- **Lys12 is not glycated** (PubMed 7358733), an experimentally verified negative result distinguishing this lysine from other glycation sites in hemoglobin.

The protein is subject to proteolytic cleavage by the hookworm *Necator americanus* protease APR-2 at multiple sites: between residues 9–10, 14–15, 25–26, 30–31, and 46–47 (PubMed 12552433; S1). These cleavages are part of the parasite's hemoglobin digestion strategy and occur in the flexible N-terminal region and early helices.

### Homologs, Paralogs, and Family Evolution

The human alpha-globin cluster contains multiple alpha-like genes that arose through successive duplication events: **HBA1, HBA2, HBZ (zeta), HBM (mu), HBQ1 (theta)**. UniProt interaction data show that the alpha chain (P69905) physically interacts with the products of HBB (32 experiments), HBD (3), HBE1 (4), HBG2 (3), and HBQ1 (3) (S1), confirming that the alpha subunit can pair with multiple beta-like globins to form developmentally regulated tetramers: embryonic (zeta2-epsilon2, zeta2-gamma2), fetal (alpha2-gamma2), and adult (alpha2-beta2, alpha2-delta2) hemoglobins.

The "Hemoglobin, alpha-type" family (IPR002338) includes the zeta, mu, theta, and related Hb subunits (CDD cd08927), indicating that all alpha-like globins share a common ancestor. The "Hemoglobin, pi" family (IPR002339) is a more restricted PRINTS-based grouping that detects the helical subfragments.

The globin fold (IPR009050, IPR012292) is ancient and widespread, found in bacteria, plants, and animals. The presence of P69905 in the Globin/Protoglobin superfamily reflects the deep evolutionary origin of this oxygen-binding domain, which has diversified into myoglobins, hemoglobins, neuroglobins, cytoglobins, and microbial globins while preserving the core 3-on-3 helical sandwich architecture.

### Experimental Structure Evidence

The RCSB PDB entry 1A00 (S38) provides an X-ray crystal structure of a hemoglobin mutant at 2.0 Å resolution, containing 4 polymer chains (2 alpha-like and 2 beta-like), 4 heme groups, and 216 solvent atoms. The deposited polymer monomer counts are 141 and 146 for the two chain types, consistent with the mature alpha chain (141 residues) and a beta chain variant (146 residues). The structure confirms the heterotetrameric assembly (alpha2-beta2) and the presence of four heme b molecules coordinated by the conserved histidines. This experimental structure validates the mature-chain length of 141 residues for alpha-globin.

### Model Predictions vs. Experimental Evidence

Several ESM2-650M-based predictions were generated for P69905 (S30–S35, plus activity/binding site predictions):

- **Solubility** (DeepSol): predicted class 1 (soluble) with probability 0.990. This is consistent with hemoglobin's well-known high solubility in erythrocyte cytoplasm.
- **Subcellular localization** (DeepLocMulti): predicted class 1 (cytoplasmic) with probability 0.956. This matches the known cytosolic localization of hemoglobin in red blood cells (S1, tissue specificity).
- **Membrane protein** (DeepLocBinary): predicted non-membrane (class 1) with probability 0.836. Consistent with hemoglobin being a soluble cytosolic protein.
- **Metal ion binding** (MetalIonBinding): predicted binder (class 1) with probability 0.952. Consistent with heme iron coordination.
- **Stability** (Thermostability): predicted value 0.590 (scale not specified in source). This is a model output without direct experimental calibration for this protein.
- **Sorting signal** (SortingSignal): predicted class vector with index 6 (cytoplasmic) having probability 0.721. Consistent with cytosolic localization.
- **Activity site** (VenusX_Res_Act_MP90): all 142 residues predicted as non-activity-site (class 0) with probabilities >0.92 for all positions. This model does not identify catalytic residues, consistent with hemoglobin's non-enzymatic oxygen transport function.
- **Binding site** (VenusX_Res_BindI_MP90): predicted binding residues at positions 55–64 (0-indexed positions 54–63 in the probability array), corresponding to precursor residues 55–64. This region includes His58 (distal histidine) and surrounding residues forming the heme pocket. The prediction is consistent with the experimentally annotated O₂ binding site at His58 (S1).

The binding site prediction from ESM2-650M identifies a contiguous stretch (residues 55–64) as binding-relevant, which overlaps the experimentally validated distal histidine position. However, the model does not specifically predict His88 (proximal histidine) as a binding residue, and the predicted region is broader than the single annotated residue. This illustrates that model predictions can provide complementary regional information but should not be equated with experimentally determined binding sites.

### Clinical Variant Context

The disease annotations for P69905 include alpha-thalassemia (MIM 604131), hemoglobin H disease (MIM 613978), and Heinz body anemias (MIM 140700) (S1). The alpha-thalassemias result from reduced or absent alpha-globin production, with severity depending on how many of the four alpha genes are affected. The mRNA-based diagnostic strategy (S8) and 3'UTR variant analysis (S9) represent recent advances in detecting non-deletional mutations that would be missed by conventional deletion screening.

### Summary of Key Distinctions

- **Precursor vs. mature chain**: The 142-residue precursor includes Met1, which is removed; the mature chain is 141 residues (positions 2–142).
- **Gene redundancy**: HBA1 and HBA2 encode identical proteins; the shared UniProt entry reflects this.
- **Experimental vs. predicted**: Binding sites at His58 and His88 are experimentally annotated (PROSITE rule, ECO:0000255); the ESM2 binding site prediction identifies a broader region (55–64) that includes His58 but not His88.
- **Family membership**: Multiple complementary databases (Pfam, PRINTS, CDD, PANTHER, SCOP, CATH) place P69905 in the globin family, alpha-type subfamily, with the full precursor in the Globin-like superfamily.
- **Conservation**: The globin fold spans the entire mature chain; the "Hemoglobin, pi" fragments identify conserved helical segments; the absence of isoleucine is a distinctive compositional feature.

## 2. Function, catalysis & pathways

### Function, Catalysis & Pathways of Human Hemoglobin Subunit Alpha (P69905)

### Molecular Function and Oxygen Transport

Hemoglobin subunit alpha (encoded by HBA1 and HBA2; UniProt P69905) is the alpha-globin component of human hemoglobin, functioning primarily in oxygen transport from the lungs to peripheral tissues [S1](https://www.uniprot.org/uniprotkb/P69905). The mature protein comprises residues 2–142 following removal of the initiator methionine (Met1), as experimentally confirmed [S1](https://www.uniprot.org/uniprotkb/P69905). The protein belongs to the globin family (PROSITE PRU00238) and contains a globin domain spanning residues 2–142 [S1, S24].

The canonical molecular function is oxygen binding and transport. InterPro annotations assign GO:0019825 (oxygen binding), GO:0020037 (heme binding), and GO:0015671 (oxygen transport) to the alpha-type hemoglobin family (IPR002338) and globin/Protoglobin superfamily (IPR012292) [S24](https://www.ebi.ac.uk/interpro/protein/UniProt/P69905/). The protein also carries GO:0005506 (iron ion binding) via InterPro annotation [S23](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905).

### Heme Coordination and Oxygen-Binding Sites

Experimental structural data from X-ray crystallography (PDB 1A00, 2.0 Å resolution) confirm the heterotetrameric assembly containing four heme groups (HEM) per hemoglobin molecule, with four inter-molecular metallic bonds coordinating the iron centers [S38](https://www.rcsb.org/structure/1A00). The structure comprises two alpha chains (141 residues in the mature form) and two beta chains (146 residues), with a total molecular weight of 64.57 kDa [S38](https://www.rcsb.org/structure/1A00).

UniProt annotates two key binding sites based on PROSITE rules (ECO:0000255):
- **His59**: oxygen (O₂) binding site (ChEBI:15379) [S1](https://www.uniprot.org/uniprotkb/P69905)
- **His88**: heme b iron coordination (ChEBI:60344; Fe: ChEBI:18248), designated as the proximal binding residue [S1](https://www.uniprot.org/uniprotkb/P69905)

These histidine residues coordinate the heme iron, with His88 providing the proximal axial ligand and His59 contributing to oxygen stabilization in the distal pocket. The iron ion is additionally coordinated by the four porphyrin nitrogens of heme b.

### Quaternary Structure and Subunit Interactions

Hemoglobin subunit alpha assembles into developmentally regulated heterotetramers [S1](https://www.uniprot.org/uniprotkb/P69905):
- **Adult hemoglobin A (HbA)**: two alpha chains + two beta chains (HBB)
- **Adult hemoglobin A2 (HbA2)**: two alpha chains + two delta chains (HBD)
- **Fetal hemoglobin F (HbF)**: two alpha chains + two gamma chains (HBG2)
- **Embryonic hemoglobin Gower-2**: two alpha chains + two epsilon chains (HBE1)

Experimental interaction data (IntAct) document 32 experiments confirming HBA–HBB interaction, with additional interactions for HBD (3 experiments), HBE1 (4), HBG2 (3), and HBQ1 (3) [S1](https://www.uniprot.org/uniprotkb/P69905). The alpha-hemoglobin stabilizing protein (AHSP, Q9NZD4) interacts with HBA (3 experiments), consistent with its chaperone role in preventing alpha-globin precipitation [S1](https://www.uniprot.org/uniprotkb/P69905). Additional reported interactors include CYB5R3 (cytochrome b5 reductase, 2 experiments), NOS3 (endothelial nitric oxide synthase, 2 experiments), and several keratin family members (KRT31, KRT34, KRT40) [S1](https://www.uniprot.org/uniprotkb/P69905).

### Catalytic and Enzymatic Activities

Although hemoglobin is primarily an oxygen transport protein, QuickGO annotations assign two catalytic activities based on direct assay evidence (IDA, ECO:0000314; PMID:19740759):
- **GO:0004601** (peroxidase activity) — contributes_to
- **GO:0031720** (nitrite reductase [NO-forming] activity) — contributes_to

These annotations indicate that hemoglobin subunit alpha contributes to peroxidase and nitrite reductase activities, though the physiological significance and specific assay conditions are not detailed in the available annotation. The peroxidase activity likely relates to hemoglobin's ability to reduce hydrogen peroxide, while nitrite reductase activity converts nitrite to nitric oxide under hypoxic conditions.

### Proteolytic Processing and Bioactive Peptide

A functionally distinct product arises from proteolytic cleavage: **hemopressin** (residues 96–104) is a bioactive peptide released from hemoglobin subunit alpha [S1](https://www.uniprot.org/uniprotkb/P69905). Experimental evidence (PubMed:18077343) demonstrates that hemopressin acts as an **antagonist peptide of cannabinoid receptor CNR1**, efficiently blocking CNR1 signaling [S1](https://www.uniprot.org/uniprotkb/P69905). This represents a moonlighting function where a hemoglobin-derived peptide participates in endocannabinoid signaling modulation.

### Microbial Interactions and Cleavage Sites

The protein is subject to cleavage by the hookworm *Necator americanus* protease apr-2 at multiple sites (PubMed:12552433) [S1](https://www.uniprot.org/uniprotkb/P69905):
- Between residues 9–10
- Between residues 14–15
- Between residues 25–26
- Between residues 30–31
- Between residues 46–47

These cleavages likely facilitate parasite hemoglobin digestion. Additionally, hemoglobin subunit alpha interacts with *Staphylococcus aureus* protein IsdB (PubMed:29109153), a hemoglobin receptor involved in iron acquisition [S1](https://www.uniprot.org/uniprotkb/P69905).

### Post-Translational Modifications

Experimental evidence documents several modifications [S1](https://www.uniprot.org/uniprotkb/P69905):
- **Phosphorylation**: Ser4 phosphoserine (PubMed:24275569)
- **Succinylation**: Lys8 N6-succinyllysine (inferred from mouse ortholog P01942)
- **Glycation**: residue 12 is reported as "not glycated" (PubMed:7358733), suggesting site-specific glycation patterns
- **N-terminal processing**: initiator methionine removed (multiple PubMed sources)

### Cellular Localization and Expression

UniProt annotates tissue specificity as **red blood cells** [S1](https://www.uniprot.org/uniprotkb/P69905). The protein is cytosolic, consistent with its role in erythrocyte oxygen transport. Reactome pathways place hemoglobin in erythrocyte gas exchange processes [S27](https://reactome.org/ContentService/data/mapping/UniProt/P69905/pathways):
- **R-HSA-1237044**: Erythrocytes take up carbon dioxide and release oxygen
- **R-HSA-1247673**: Erythrocytes take up oxygen and release carbon dioxide
- **R-HSA-2168880**: Scavenging of heme from plasma
- **R-HSA-9707564**: Cytoprotection by HMOX1
- **R-HSA-9707616**: Heme signaling
- **R-HSA-9927020**: Heme assimilation (disease pathway)

### Sequence Properties and Biophysical Characteristics

ProtParam calculations for the 142-residue precursor provide: molecular weight 15,257.36 Da; theoretical pI 8.717; GRAVY 0.0479; instability index 6.974 (classified as stable); aromaticity 0.0775 [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html). Amino acid composition shows high histidine content (10 residues), consistent with heme coordination and pH-dependent oxygen binding (Bohr effect) [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html).

### Model Predictions vs. Experimental Evidence

Several ESM2-650M-based predictions are available for comparison with experimental data:

**Subcellular localization** (DeepLocMulti): predicts class 1 (cytoplasmic) with probability 0.956 [S31], consistent with the known cytosolic localization in erythrocytes. The sorting signal prediction also assigns class 7 (cytoplasmic) with probability 0.721 [S35].

**Metal ion binding** (MetalIonBinding): predicts metal binding (class 1, probability 0.952) [S33], consistent with the experimentally confirmed heme iron coordination.

**Membrane protein** (DeepLocBinary): predicts non-membrane protein (class 1, probability 0.836) [S32], consistent with the soluble cytosolic nature of hemoglobin.

**Solubility** (DeepSol): predicts soluble (class 1, probability 0.990) [S30], consistent with hemoglobin's high solubility in erythrocyte cytosol.

**Thermostability** (Thermostability): predicts stability score 0.590 [S34], a moderate value consistent with hemoglobin's known thermal lability in certain variants (e.g., Heinz body anemias involve heat-labile hemoglobins [S1](https://www.uniprot.org/uniprotkb/P69905)).

**Binding site prediction** (VenusX_Res_BindI_MP90): predicts binding residues at positions 53–62 (10 consecutive residues). This region encompasses the experimentally annotated oxygen-binding residue His59 and the heme pocket region, providing partial agreement with experimental data. However, the prediction does not identify His88 (the proximal heme ligand), representing a discrepancy between model prediction and experimental annotation.

### Disease Relevance and Pathway Integration

Alpha-thalassemia results from variants affecting HBA1/HBA2, ranging from asymptomatic loss of one gene to lethal hemoglobin Bart hydrops fetalis when all four alpha genes are deleted [S1](https://www.uniprot.org/uniprotkb/P69905). Hemoglobin H disease (loss of three alpha genes) produces beta-chain tetramers with high oxygen affinity but poor tissue delivery, causing severe anemia [S1](https://www.uniprot.org/uniprotkb/P69905). Heinz body anemias involve unstable hemoglobin variants that precipitate as inclusions [S1](https://www.uniprot.org/uniprotkb/P69905).

Recent transcriptomic studies in dairy cows show HBA1 expression changes during early pregnancy [S41](https://europepmc.org/article/MED/41527033), and placental studies in fetal growth restriction demonstrate reduced HBA1 protein levels alongside compensatory iron utilization pathways [S42](https://europepmc.org/article/MED/41697720). These findings, while from non-human or placental contexts, suggest conserved regulatory roles beyond simple oxygen carriage.

### Summary

Hemoglobin subunit alpha is a well-characterized oxygen transport protein with experimentally confirmed heme coordination (His59, His88), heterotetrameric assembly, and erythrocyte localization. Beyond transport, it contributes peroxidase and nitrite reductase activities, serves as a precursor for the bioactive peptide hemopressin (CNR1 antagonist), and interacts with microbial pathogens. Model predictions largely agree with experimental data for localization, solubility, and metal binding, though binding-site prediction only partially recapitulates the experimentally defined heme coordination residues.

## 3. Structure, dynamics & ligand binding

### Structure, Dynamics & Ligand Binding of Human Hemoglobin Subunit Alpha (P69905)

### Experimental Structure Coverage and Methods

Human hemoglobin subunit alpha (P69905) is among the most extensively characterized proteins in structural biology, with the PDBe mapping listing 714 total structures and 20 best-representative entries covering the full-length mature chain (residues 2–142) [S29](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905). The highest-resolution X-ray diffraction structures include 1bab at 1.5 Å (chains A and C, full coverage), 1bz1 at 1.59 Å, and 7qu4 at 1.66 Å [S29](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905). Additional X-ray structures at 1.8–2.28 Å (7ud7, 7ud8, 7uf6, 7uf7, 8vyl, 6kye) and cryo-EM structures at 2.24–2.27 Å (8wj0, 9vib, 8wj1) provide full-chain coverage [S29](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905). The 1bab entry is particularly notable as hemoglobin Thionville, an alpha-chain variant with Glu substituted for Val at NA1 and an acetylated methionine N-terminus, crystallized at 1.5 Å [S25, S29]. Foldseek searches against PDB100 identify numerous high-confidence matches including 1bab (100% sequence identity, full-length alignment), 1bz1 (99.2% identity), 7dy4 (hemoglobin M Boston, 99.2%), and 1o1o (98.5% identity) [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0).

### Oligomerization and Quaternary Structure

UniProt annotation describes the functional assembly as a heterotetramer: two alpha chains with two beta chains in adult hemoglobin A (HbA), two delta chains in HbA2, two epsilon chains in embryonic Gower-2, or two gamma chains in fetal hemoglobin F [S1](https://www.uniprot.org/uniprotkb/P69905). The IntAct interaction database records 32 experimental interaction entries between P69905 and HBB (P68871), plus interactions with HBD (3 experiments), HBE1 (4), HBG2 (3), and HBQ1 (3) [S1](https://www.uniprot.org/uniprotkb/P69905). These experimental interaction counts support the well-established tetrameric assembly, though the interaction evidence itself does not define stoichiometry or interface geometry—that information comes from the crystallographic structures.

The deposited structures consistently contain four polymer chains per assembly (e.g., 1A00 has 4 polymer instances, 574 modeled monomers, 4 heme groups, and 216 solvent atoms) [S38](https://www.rcsb.org/structure/1A00). The 1A00 entry, despite its mutant title (Valβ1Met, Trpβ37Tyr), provides a 2.0 Å structure with full alpha-chain coverage and four heme ligands per tetramer [S38](https://www.rcsb.org/structure/1A00).

### Domain Architecture and Heme Binding

InterPro analysis identifies the globin domain (IPR000971) spanning residues 2–142, the hemoglobin alpha-type family (IPR002338) covering residues 3–142, and the globin-like superfamily (IPR009050) across the full sequence [S24](https://www.ebi.ac.uk/interpro/protein/UniProt/P69905/). The globin/Protoglobin superfamily (IPR012292) also spans residues 2–142 [S24](https://www.ebi.ac.uk/interpro/protein/UniProt/P69905/). PROSITE annotation assigns the globin domain from residue 2 to 142 [S1](https://www.uniprot.org/uniprotkb/P69905).

UniProt annotates two key binding sites: His59 as an O₂ binding site (ChEBI:15379) and His88 as the proximal heme-binding residue coordinating the iron atom (ChEBI:60344 heme b, ChEBI:18248 Fe) [S1](https://www.uniprot.org/uniprotkb/P69905). These annotations derive from PROSITE ProRule PRU00238 (ECO:0000255, sequence-based inference), not from direct experimental determination in this entry—though the heme coordination is overwhelmingly confirmed by the crystallographic structures containing HEM ligands [S29, S38].

### Ligand Binding and Conformational States

The 1A00 structure contains four HEM non-polymer entities per tetramer, with inter-molecular metallic bonds (4 total) consistent with iron coordination [S38](https://www.rcsb.org/structure/1A00). The deposited structures represent multiple functional states: 1gli is deoxyhemoglobin T38W with V1G substitutions, 1o1o is deoxyhemoglobin with V1M/V62L (alpha) and V1M/V67L (beta) substitutions, and 1y0t captures T-to-T(high) quaternary transitions in deoxy low-salt conditions [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0). These distinct deposited states enable comparative analysis of R/T conformational transitions, though the specific structural coordinates and state assignments require examination of individual entries.

### Disorder and Predicted Structure

AlphaFold DB provides model AF-P69905-F1 with a global pLDDT of 98.06, indicating very high per-residue confidence [S28](https://alphafold.ebi.ac.uk/entry/P69905). The model has 0.0% very-low-confidence residues and 0.7% low-confidence residues, with no large disordered regions predicted. The AlphaFold interpretation explicitly notes that predicted structures and pLDDT are not experimental structure or binding validation [S28](https://alphafold.ebi.ac.uk/entry/P69905). Foldseek comparison of the AlphaFold model against the experimental PDB100 database returns the 1bab structure as the top hit (score 1039, E-value 6.24e-21, 100% sequence identity, full-length alignment), confirming that the predicted model closely matches experimentally determined conformation [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0).

### Sequence Properties and Biophysical Predictions

ProtParam calculations for the 142-residue precursor (including initiator Met) give a molecular weight of 15,257.36 Da, theoretical pI of 8.717, GRAVY of 0.0479, instability index of 6.974 (classified stable), and aromaticity of 0.0775 [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html). The mature chain begins at residue 2 after initiator methionine cleavage, which is experimentally confirmed (ECO:0000269) by multiple publications [S1](https://www.uniprot.org/uniprotkb/P69905).

ESM2-650M-based predictions provide complementary but unvalidated estimates: solubility class 1 (probability 0.990), cytosolic localization (class 1, probability 0.956), non-membrane protein (probability 0.836), metal ion binding (probability 0.952), and thermostability score 0.590 [S30–S34]. The sorting signal prediction assigns class 7 (probability 0.721), which in the DeepLocMulti scheme corresponds to a specific localization category, though the mapping is not provided in the source [S35]. These predictions align with known biology (cytosolic, heme-binding, soluble) but should not be treated as experimental validation.

The binding-site prediction from VenusX_Res_BindI_MP90 identifies residues 53–62 (1-indexed) as a contiguous binding region [source unavailable]. This predicted segment overlaps the experimentally annotated O₂-binding His59 and lies adjacent to the proximal heme ligand His88, though the prediction does not extend to His88 itself. The activity-site prediction (VenusX_Res_Act_MP90) returns no residues above threshold [source unavailable]. These residue-level predictions are model outputs requiring experimental confirmation.

### Proteolytic Processing and Functional Peptides

UniProt documents that residues 96–104 constitute hemopressin, a peptide that acts as an antagonist of cannabinoid receptor CNR1 [S1](https://www.uniprot.org/uniprotkb/P69905). This peptide is released from the alpha chain and represents a functional product beyond oxygen transport. Additionally, the alpha chain undergoes cleavage by Necator americanus APR-2 at multiple sites (residues 9–10, 14–15, 25–26, 30–31, 46–47) during hookworm infection [S1](https://www.uniprot.org/uniprotkb/P69905). The initiator methionine is removed in the mature protein, and residue 4 can be phosphorylated (phosphoserine, ECO:0007744) [S1](https://www.uniprot.org/uniprotkb/P69905).

### Structural Gaps and Uncertainties

Despite exceptional experimental coverage, several aspects remain incompletely characterized at atomic resolution: (1) the precise conformational ensemble of the hemopressin peptide (residues 96–104) when released from the holoprotein; (2) the structural basis of alpha-chain interactions with non-globin partners such as AHSP (3 experiments), CYB5R3 (2), NOS3 (2), and various keratin proteins [S1](https://www.uniprot.org/uniprotkb/P69905); (3) the conformational effects of the many disease-associated variants catalogued in HbVar, only some of which have deposited structures. The 714 PDB entries provide ample material for comparative analyses, but systematic variant-structure mapping remains incomplete.

## 4. Interactions, expression & regulation

### Interactions, Expression & Regulation of Hemoglobin Subunit Alpha (P69905)

### Protein Partners and Complexes

Hemoglobin subunit alpha (HBA) forms the canonical hemoglobin heterotetramer with non-alpha globin chains. UniProt documents the subunit architecture: adult hemoglobin A (HbA) comprises two alpha and two beta chains; adult hemoglobin A2 (HbA2) contains two alpha and two delta chains; fetal hemoglobin F (HbF) uses two alpha and two gamma chains; embryonic hemoglobin Gower-2 employs two alpha and two epsilon chains [S1](https://www.uniprot.org/uniprotkb/P69905). These complexes are experimentally supported by IntAct interaction data: HBA–HBB (P68871) has 32 experiments, HBA–HBE1 (P02100) has 4, and HBA–HBD (P02042), HBA–HBG2 (P69892), and HBA–HBQ1 (P09105) each have 3 experiments [S1](https://www.uniprot.org/uniprotkb/P69905). QuickGO annotations confirm physical interactions with HBB (P68871) via IPI evidence across multiple publications (PMID:10390349, 10930828, 11724557, 1552945, 15835899, 16169070, 28665412, 29997244, 30833564) and with HBE1 (PMID:11159543) [S23](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905).

Beyond globin partners, HBA interacts with alpha-hemoglobin stabilizing protein (AHSP, Q9NZD4) in 3 experiments [S1](https://www.uniprot.org/uniprotkb/P69905). AHSP is a chaperone that binds free alpha-globin, preventing its precipitation and maintaining erythroid viability. Additional IntAct partners include CYB5R3 (cytochrome b5 reductase, 2 experiments), NOS3 (endothelial nitric oxide synthase, 2 experiments), and several keratins (KRT31, KRT34, KRT40, 3 experiments each) [S1](https://www.uniprot.org/uniprotkb/P69905). The keratin interactions may reflect non-erythroid expression or experimental artifacts; their physiological relevance remains unclear. CCDC57 and NOTCH2NLC also appear as interactors with 3 experiments each [S1](https://www.uniprot.org/uniprotkb/P69905).

STRING functional association analysis (score 0–1) ranks HBB highest (0.999), followed by HBE1 (0.998), AHSP (0.998), HBA1 (0.998), HBG2 (0.996), HP/haptoglobin (0.996), HBG1 (0.994), HBD (0.994), HBQ1 (0.986), and CYB5R3 (0.978) [S26](https://string-db.org/cgi/network?identifiers=P69905&species=9606). These scores integrate multiple evidence channels including experiments, databases, and text mining; they indicate functional association rather than direct physical binding. The haptoglobin interaction is notable: haptoglobin binds free hemoglobin dimers for clearance, consistent with the "Scavenging of heme from plasma" Reactome pathway [S27](https://reactome.org/ContentService/data/mapping/UniProt/P69905/pathways).

### Regulatory Networks and Expression Control

HBA is encoded by two genes, HBA1 and HBA2, located in the alpha-globin cluster [S1](https://www.uniprot.org/uniprotkb/P69905). The two genes produce identical proteins, complicating variant attribution. A 2026 study developed an mRNA-based genotyping strategy combining Sanger sequencing with multiplex quantitative fluorescence PCR (MQF-PCR) to analyze full-length coding sequences and expression levels of HBA2/HBA1/HBB in peripheral blood [S8](https://europepmc.org/article/MED/41735777). Among 103 pre-genotyped samples (21 wild-type, 49 alpha-globin mutants, 33 HBB mutants), the method detected 14 coding-region substitutions and identified gross deletions via peak area ratios (PAR1 = PA_HBA2/PA_HBA1; PAR2 = PA_HBB/PA_HBA). This demonstrates that relative expression ratios between the duplicated alpha genes and beta genes are diagnostically informative.

Post-transcriptional regulation is critical. A 2025 report identified two novel HBA1 3'UTR mutations causing alpha-thalassemia: HBA1:c.*119_120insT (five nucleotides downstream of the transcription termination signal) and HBA1:c.*150C>A (40 nucleotides downstream) [S9](https://europepmc.org/article/MED/41388082). In silico analyses predicted disruption of RNA secondary structure, impaired interactions with RNA-binding proteins HuR and AUF1, altered microRNA binding (e.g., miR-16-5p), and interference with polyadenylation signals, leading to mRNA instability and reduced alpha-globin synthesis [S9](https://europepmc.org/article/MED/41388082). These findings emphasize that the 3'UTR is a regulatory hub for globin expression, though the predictions require experimental validation.

### Tissue Specificity and Localization

UniProt states tissue specificity as "Red blood cells" [S1](https://www.uniprot.org/uniprotkb/P69905). The ESM2-650M DeepLocMulti model predicts cytosolic localization with probability 0.956 (class 1) [S31], consistent with the known soluble cytoplasmic localization of hemoglobin in erythrocytes. The DeepLocBinary membrane protein classifier predicts non-membrane (probability 0.836) [S32], and the SortingSignal model predicts no classical sorting signal (class index 6, probability 0.721) [S35]. These predictions align with experimental knowledge: hemoglobin is a soluble cytoplasmic protein without membrane anchoring or secretory pathway targeting.

The DeepSol solubility model predicts high solubility (class 1, probability 0.990) [S30], consistent with hemoglobin's abundance in red blood cells at ~340 mg/mL. The MetalIonBinding model predicts metal ion binding (class 1, probability 0.952) [S33], consistent with the heme iron coordination documented in UniProt features: His59 binds O2 and His88 coordinates heme iron (proximal binding residue) [S1](https://www.uniprot.org/uniprotkb/P69905). The thermostability model predicts a stability score of 0.590 [S34], though this value's interpretation relative to other proteins is not calibrated.

### Signaling and Non-Canonical Functions

A notable non-canonical function involves the hemopressin peptide (residues 96–104), which is released from the alpha chain and acts as an antagonist of cannabinoid receptor CNR1 [S1](https://www.uniprot.org/uniprotkb/P69905). Hemopressin binding blocks CNR1 signaling (PubMed:18077343) [S1](https://www.uniprot.org/uniprotkb/P69905). This represents a bioactive peptide hidden within a globin sequence, suggesting proteolytic processing can generate signaling molecules.

HBA also participates in heme-related signaling pathways. Reactome lists six pathways: "Erythrocytes take up carbon dioxide and release oxygen" (R-HSA-1237044), "Erythrocytes take up oxygen and release carbon dioxide" (R-HSA-1247673), "Scavenging of heme from plasma" (R-HSA-2168880), "Cytoprotection by HMOX1" (R-HSA-9707564), "Heme signaling" (R-HSA-9707616), and "Heme assimilation" (R-HSA-9927020, disease-related) [S27](https://reactome.org/ContentService/data/mapping/UniProt/P69905/pathways). The HMOX1 cytoprotection and heme signaling pathways connect hemoglobin degradation products (heme, biliverdin, carbon monoxide) to cellular stress responses.

### Species-Specific and Microbial Interactions

HBA is cleaved by the hookworm protease apr-2 from Necator americanus at multiple sites: residues 9–10, 14–15, 25–26, 30–31, and 46–47 [S1](https://www.uniprot.org/uniprotkb/P69905). This cleavage liberates hemopressin-related peptides, potentially modulating host inflammation. Additionally, HBA interacts with Staphylococcus aureus protein IsdB (PubMed:29109153) [S1](https://www.uniprot.org/uniprotkb/P69905), a hemoglobin receptor involved in iron acquisition during infection. These microbial interactions illustrate how pathogens exploit hemoglobin as an iron source and how host-parasite coevolution shapes globin functions.

### Disease-Associated Regulation

Alpha-thalassemia results from variants affecting HBA1/HBA2, ranging from complete gene deletion (alpha-0 thalassemia, causing hydrops fetalis) to point mutations in coding or regulatory regions [S1](https://www.uniprot.org/uniprotkb/P69905). Hemoglobin H disease arises from loss of three alpha genes, leading to toxic beta-4 tetramers [S1](https://www.uniprot.org/uniprotkb/P69905). Heinz body anemias involve unstable hemoglobin variants that precipitate as inclusions [S1](https://www.uniprot.org/uniprotkb/P69905). The 3'UTR mutations described above expand the non-deletional alpha-thalassemia spectrum [S9](https://europepmc.org/article/MED/41388082), highlighting that regulatory region variants can phenocopy coding mutations.

### Model Predictions vs. Experimental Evidence

The ESM2-650M predictions generally corroborate experimental data: cytosolic localization (DeepLocMulti), non-membrane (DeepLocBinary), metal binding (MetalIonBinding), and high solubility (DeepSol) all match known biology. However, these are model predictions trained on sequence features; they do not validate function. The binding site prediction (VenusX_Res_BindI_MP90) identifies residues 55–64 as a binding interface, which overlaps the experimentally annotated O2-binding His59 and heme-coordinating His88 region [S1](https://www.uniprot.org/uniprotkb/P69905). This concordance is suggestive but not confirmatory. The activity site prediction (VenusX_Res_Act_MP90) returns all zeros, indicating no enzyme active site, consistent with hemoglobin's transport rather than catalytic function.

The computed ProtParam values (molecular weight 15,257.36 Da; pI 8.72; GRAVY 0.048; instability index 6.97) [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html) describe sequence properties only and carry no functional information. The instability index below 40 suggests a stable protein in vitro, consistent with hemoglobin's long-lived erythrocyte residence, though this heuristic does not account for cellular degradation pathways.

### Gaps and Uncertainties

Several interactions lack functional validation: the keratin partners (KRT31, KRT34, KRT40) and CCDC57/NOTCH2NLC interactions have no known physiological role in erythroid biology. The NOS3 interaction (2 experiments) may relate to hemoglobin's nitric oxide scavenging or nitrite reductase activity, but the mechanistic details remain incomplete. The QuickGO annotations include GO:0004601 (peroxidase activity) and GO:0031720 (haptoglobin binding) with IDA evidence (PMID:19740759) [S23](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905), suggesting additional enzymatic functions beyond oxygen transport. The tissue specificity annotation ("Red blood cells") may be incomplete, as alpha-globin is reported in other contexts, though non-erythroid expression remains controversial. The 3'UTR regulatory predictions (HuR, AUF1, miR-16-5p) are in silico only and require experimental confirmation.

## 5. Variants, modifications & phenotypes

### Variants, Modifications & Phenotypes of Human Hemoglobin Subunit Alpha (P69905)

### Sequence Context and Nomenclature

The UniProt entry P69905 represents the human hemoglobin subunit alpha, a 142-residue protein encoded by two duplicated genes, *HBA1* and *HBA2*, which produce identical protein products [S1](https://www.uniprot.org/uniprotkb/P69905). Residue numbering throughout this chapter follows the UniProt mature-chain convention: the initiator methionine (Met1) is removed co-translationally, and the mature chain spans residues 2–142 [S1](https://www.uniprot.org/uniprotkb/P69905). This numbering differs from the historical "HGVS" alpha-globin numbering used in much of the clinical literature, where the mature N-terminus (UniProt Val2) is designated position 1; readers should exercise caution when comparing variant designations across sources. The sequence caution entry for BAD97112.1 (erroneous initiation) underscores that some database sequences may include the initiator methionine or use alternative start sites [S1](https://www.uniprot.org/uniprotkb/P69905).

### Proteolytic Maturation and the Initiator Methionine

The initiator methionine is removed in the mature protein, as documented by multiple experimental studies (PubMed IDs 12665801, 13872627, 13954546, 14093912) [S1](https://www.uniprot.org/uniprotkb/P69905). The mature chain (residues 2–142) constitutes the functional hemoglobin subunit. A notable exception is the Thionville variant, in which the initiator methionine is not cleaved and instead becomes acetylated [S1](https://www.uniprot.org/uniprotkb/P69905). This variant demonstrates that the N-terminal processing machinery can be perturbed by specific sequence changes, with functional consequences for the mature protein.

### Bioactive Peptide: Hemopressin

Proteolytic processing of the alpha chain generates hemopressin, a nine-residue peptide spanning positions 96–104 (PVNFKFLSH in single-letter code) [S1](https://www.uniprot.org/uniprotkb/P69905). Hemopressin functions as an antagonist of the cannabinoid receptor CNR1, blocking receptor signaling (PubMed 18077343) [S1](https://www.uniprot.org/uniprotkb/P69905). This peptide represents a biologically active cleavage product with functions distinct from the intact hemoglobin subunit—an example of a "moonlighting" peptide derived from a well-characterized oxygen carrier. The functional evidence is experimental (ECO:0000305, curator inference from PubMed), not merely predicted.

### Post-Translational Modifications

### Phosphorylation
Serine 4 (UniProt numbering; Ser3 in mature-chain numbering) is experimentally documented as a phosphoserine (PubMed 24275569) [S1](https://www.uniprot.org/uniprotkb/P69905). The evidence code ECO:0007744 indicates this was identified by high-throughput mass spectrometry. The functional significance of alpha-globin phosphorylation in erythrocytes remains incompletely characterized.

### Succinylation
Lysine 8 (UniProt numbering) can carry N6-succinyllysine modification, annotated as "alternate" [S1](https://www.uniprot.org/uniprotkb/P69905). This annotation is inferred from sequence similarity to mouse hemoglobin alpha (UniProt P01942) by curator judgment (ECO:0000250), not directly demonstrated in human protein. This distinction matters: the modification is plausible but not experimentally confirmed in the human ortholog.

### Glycation
Residue 12 (UniProt numbering; Lys11 in mature numbering) is annotated as "Not glycated" [S1](https://www.uniprot.org/uniprotkb/P69905). This is an experimentally supported negative annotation (PubMed 7358733), indicating that this lysine is not a site of non-enzymatic glycation despite the general susceptibility of hemoglobin to glycation. This negative result is biologically informative because it contrasts with beta-globin lysine residues that are glycated in diabetes.

### Microbial Cleavage Sites

The hookworm *Necator americanus* protease APR-2 cleaves human hemoglobin alpha at multiple sites: between residues 9–10, 14–15, 25–26, 30–31, and 46–47 (UniProt numbering) [S1](https://www.uniprot.org/uniprotkb/P69905). These cleavage events, documented experimentally (PubMed 12552433), represent pathogen-driven proteolysis of host hemoglobin during infection. The biological context is nutritional: the hookworm digests host hemoglobin as an iron source. These sites are distinct from the endogenous processing that generates hemopressin.

### Disease-Associated Variants and Phenotypes

### Alpha-Thalassemia
Alpha-thalassemia results from reduced or absent alpha-globin synthesis, caused by deletions or point mutations in *HBA1*/*HBA2* [S1](https://www.uniprot.org/uniprotkb/P69905). The disease spectrum ranges from asymptomatic carrier states (loss of one alpha gene) to lethal hydrops fetalis (loss of all four alpha genes). The UniProt disease annotation (DI-01181) indicates the disease is caused by variants affecting the gene represented by this entry [S1](https://www.uniprot.org/uniprotkb/P69905).

### Hemoglobin H Disease
Loss of three alpha genes produces hemoglobin H disease (DI-03202), characterized by accumulation of beta-4 tetramers with high oxygen affinity but poor tissue delivery, causing severe anemia [S1](https://www.uniprot.org/uniprotkb/P69905). The evidence includes experimental support (PubMed 10569720) [S1](https://www.uniprot.org/uniprotkb/P69905).

### Heinz Body Anemias
Certain alpha-globin variants cause Heinz body anemias (DI-01698), a non-spherocytic hemolytic anemia with heat-labile hemoglobin and inclusion bodies [S1](https://www.uniprot.org/uniprotkb/P69905). The evidence is experimental (PubMed 2833478) [S1](https://www.uniprot.org/uniprotkb/P69905). This phenotype typically arises from unstable hemoglobin variants that precipitate within erythrocytes.

### Recent Clinical Variant Reports

### HBA1 3'UTR Variants (2025)
Two novel non-deletional alpha-thalassemia variants were identified in the HBA1 3'UTR [S9](https://europepmc.org/article/MED/41388082). Patient 1 (Nigerian boy, age 3) carried an insertion (HBA1:c.*119_120insT) five nucleotides downstream of the transcription termination signal. Patient 2 (Moroccan woman, age 31) carried a missense variant (HBA1:c.*150C>A) located 40 nucleotides downstream of the TTS. Both variants are predicted in silico to disrupt RNA secondary structure, impair interactions with HuR and AUF1 RNA-binding proteins, alter microRNA binding (e.g., miR-16-5p), and potentially interfere with polyadenylation signals [S9](https://europepmc.org/article/MED/41388082). These predictions are computational, not experimentally validated; the clinical phenotype (microcytosis, normal iron) is documented, but the mechanistic link to mRNA instability remains inferred.

### Hemoglobin Ariana (2025)
A novel 230 bp deletion (NC_000016.10:g.176695_176925del) in HBA1, named Hemoglobin Ariana, was identified in a Tunisian family [S10](https://europepmc.org/article/MED/40484869). The deletion affects the 5'UTR, exon 1, and part of intron 1. The proband (age 4) exhibited mild anemia, microcytosis, hypochromia, and low ferritin unresponsive to iron supplementation. The deletion was confirmed by gap-PCR, gel purification, and sequencing—experimental validation at the DNA level [S10](https://europepmc.org/article/MED/40484869).

### Hemoglobin Tozeur (2025)
A missense variant (NM_000558.5:c.85G>C; NP_000549.1:p.Ala29Pro) was identified in a Tunisian infant co-inheriting alpha-thalassemia and Hemoglobin C [S10](https://europepmc.org/article/MED/40484869). In silico tools (PolyPhen-2, SIFT, MutationTaster) predicted deleterious effects, and structural modeling (Swiss-PdbViewer, DynaMut) suggested destabilization near the heme-binding region [S10](https://europepmc.org/article/MED/40484869). These predictions are computational; no experimental protein stability data were reported. The clinical phenotype is confounded by co-inheritance of Hemoglobin C, complicating attribution of specific hematological features to the alpha-globin variant alone.

### mRNA-Based Genotyping (2026)
An integrated genotyping strategy using peripheral blood mRNA detected 14 coding-region substitutions and identified gross deletions and non-coding mutations through peak-area ratios [S8](https://europepmc.org/article/MED/41735777). This approach demonstrates that mRNA-level analysis can complement DNA-based diagnostics, particularly for variants affecting transcript stability or processing.

### Model Predictions and Their Limitations

### Sequence-Based Property Predictions
ProtParam calculations for the 142-residue precursor (including Met1) yield: molecular weight 15,257.36 Da, theoretical pI 8.717, GRAVY 0.0479, instability index 6.974 (classified as stable), aromaticity 0.0775 [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html). These values describe the unmodified precursor; the mature chain (residues 2–142) would differ slightly in mass and pI.

### ESM2-650M Predictions
The ESM2-650M model predicts high solubility (class 1, probability 0.990) [S30], cytosolic localization (class 1, probability 0.956) [S31], non-membrane protein (class 1, probability 0.836) [S32], metal ion binding (class 1, probability 0.952) [S33], and moderate thermostability (score 0.590) [S34]. The sorting signal prediction (class index 6, probability 0.721) is ambiguous given the model's class definitions [S35]. These predictions are consistent with known biology—hemoglobin is an abundant cytosolic protein that binds heme iron—but they do not validate function. The metal ion binding prediction aligns with the experimentally documented heme iron coordination at His88 (proximal) and His59 (distal) [S1](https://www.uniprot.org/uniprotkb/P69905).

### Residue-Level Binding and Activity Predictions
The VenusX binding site model predicts a contiguous binding region spanning residues 53–62 (UniProt numbering), with high probabilities for residues 56–61 [S1, prediction data]. This region overlaps the experimentally annotated O2 binding site at His59 and the heme-binding proximal histidine at His88 is not predicted as part of this contiguous region. The activity site model predicts essentially no residues above threshold (all probabilities <0.08 for class 1) [S1, prediction data]. These predictions are model outputs, not experimental measurements; they should not be used to infer catalytic activity or binding specificity without orthogonal validation.

### Evidence Quality and Confounding Distinctions

Several important distinctions emerge from this evidence synthesis:

1. **Experimental vs. inferred PTMs**: Phosphorylation at Ser4 is experimentally identified; succinylation at Lys8 is inferred from mouse ortholog similarity. These have different confidence levels.

2. **Predicted vs. validated variant effects**: The 3'UTR variants and Hemoglobin Tozeur have computational predictions of pathogenicity but lack experimental functional validation. The clinical phenotypes are documented, but mechanistic explanations remain hypothetical.

3. **Confounded phenotypes**: The Hemoglobin Tozeur case involves co-inheritance with Hemoglobin C, making it impossible to attribute specific hematological features solely to the alpha-globin variant.

4. **Numbering discrepancies**: Clinical literature often uses mature-chain numbering (Val1), while UniProt uses precursor numbering (Met1). The Ala29Pro variant in HGVS notation corresponds to UniProt position 30 (Ala30Pro), a distinction that matters for cross-referencing.

5. **Model predictions vs. biology**: ESM2 predictions of solubility, localization, and metal binding are consistent with known hemoglobin biology but provide no new mechanistic insight. The binding site prediction partially overlaps known heme-coordinating residues but is not a substitute for crystallographic or spectroscopic evidence.

### Gaps in Current Knowledge

The functional consequences of alpha-globin phosphorylation at Ser4 remain unexplored. The tissue-specific or condition-dependent regulation of hemopressin generation from full-length hemoglobin is not characterized. The mechanistic basis for how 3'UTR variants impair mRNA stability is predicted but not experimentally demonstrated. Finally, the relationship between specific alpha-globin variants and Heinz body formation is documented phenotypically but the molecular basis of inclusion body precipitation is incompletely understood at the residue level.

## 6. Biophysics, expression & production

### Biophysics, Expression & Production of Human Hemoglobin Subunit Alpha (P69905)

### Computed Sequence Properties

The UniProt entry P69905 (hemoglobin subunit alpha, 142 residues) was analyzed with Biopython ProtParam [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html). The computed molecular weight is 15,257.36 Da for the unmodified polypeptide chain, with a theoretical pI of 8.717, reflecting a basic protein (11 Lys, 3 Arg, 10 His versus 8 Asp and 4 Glu). The grand average of hydropathicity (GRAVY) is 0.0479, indicating a slightly hydrophobic protein overall. The instability index heuristic is 6.974, which is well below the threshold of 40 typically used to classify proteins as stable in solution. Aromaticity is 0.0775 (7 Phe, 3 Tyr, 1 Trp). Notably, the sequence contains zero isoleucine residues, an unusual compositional feature. The single cysteine (Cys104) is relevant for oxidative chemistry but does not form disulfide bonds in the native hemoglobin tetramer (PDB 1A00 reports zero disulfide bonds [S38](https://www.rcsb.org/structure/1A00)).

These computed values describe the isolated alpha chain; however, the biologically functional unit is the hemoglobin tetramer (α₂β₂), and the stability of the isolated alpha chain differs substantially from that of the assembled complex.

### Predicted Biophysical Properties from ESM2-650M Models

Several deep-learning predictions were generated using ESM2-650M embeddings [S30–S35]:

**Solubility (DeepSol):** Predicted class 1 (soluble) with probability 0.990. This is consistent with hemoglobin's known high solubility in erythrocyte cytosol (~330 mg/mL), though the model was trained on general protein solubility data and does not capture heme-dependent effects.

**Subcellular localization (DeepLocMulti):** Predicted class 1 with probability 0.956. The class index corresponds to "cytoplasm" in the DeepLocMulti scheme, consistent with the cytosolic localization of hemoglobin in red blood cells [S1](https://www.uniprot.org/uniprotkb/P69905).

**Membrane protein (DeepLocBinary):** Predicted non-membrane (class 1, probability 0.836), consistent with the absence of transmembrane helices.

**Metal ion binding (MetalIonBinding):** Predicted metal-binding (class 1, probability 0.952), consistent with the known iron coordination by the heme group [S1](https://www.uniprot.org/uniprotkb/P69905).

**Thermostability (Thermostability dataset):** Predicted stability score of 0.590 (scale not specified in the source; higher values generally indicate greater predicted thermostability). This is a moderate score, consistent with hemoglobin's known thermal lability—particularly the isolated alpha chain, which is less stable than the tetramer.

**Sorting signal:** Predicted class 7 (probability 0.721), which in the nine-class scheme corresponds to "no sorting signal"—consistent with a cytosolic protein lacking signal peptides or organellar targeting sequences.

**Activity site (VenusX_Res_Act_MP90):** All 142 residues predicted as non-active-site (probabilities >0.92 for non-active class at every position), consistent with hemoglobin's oxygen transport function not involving classical enzymatic catalysis.

**Binding site (VenusX_Res_BindI_MP90):** Predicted binding residues at positions 54–63 (10 consecutive residues flagged as binding). This region includes His58 (proximal histidine, coordinating heme iron) and aligns with the experimentally annotated heme-binding pocket [S1](https://www.uniprot.org/uniprotkb/P69905). The prediction is consistent with the known heme coordination site.

### Experimental Structure and Stability Evidence

The RCSB PDB entry 1A00 [S38](https://www.rcsb.org/structure/1A00) provides an X-ray structure of a hemoglobin mutant at 2.0 Å resolution, containing 4 polymer chains (2 alpha, 2 beta), 4 heme groups, and 216 solvent atoms. The structure confirms the heterotetrameric assembly with inter-molecular metallic bonds (4, corresponding to the heme iron atoms). The deposited molecular weight is 64.57 kDa for the tetramer, with polymer molecular weights of 15.15–15.9 kDa per chain.

AlphaFold DB [S28](https://alphafold.ebi.ac.uk/entry/P69905) provides a predicted monomer structure (AF-P69905-F1) with a global pLDDT of 98.06, indicating very high per-residue confidence. The fraction of very low pLDDT residues is 0.0, and low pLDDT residues comprise only 0.7% of the structure. This high confidence reflects the availability of many homologous globin structures in the training set. However, AlphaFold predicts the monomer; it does not model the tetrameric assembly or heme coordination.

### Expression and Production Considerations

Hemoglobin alpha is naturally expressed in erythroid cells at very high concentrations. For recombinant production, several constraints apply:

**Heme requirement:** Functional hemoglobin requires heme b incorporation (protoporphyrin IX with Fe²⁺) [S1](https://www.uniprot.org/uniprotkb/P69905). Recombinant expression in E. coli requires either heme supplementation or co-expression of heme biosynthesis genes. The binding site predictions and experimental annotations identify His58 (proximal) and His87 (distal) as critical for heme coordination [S1](https://www.uniprot.org/uniprotkb/P69905).

**Tetramer assembly:** The functional unit requires co-expression of beta-like globin chains. The UniProt subunit annotation [S1](https://www.uniprot.org/uniprotkb/P69905) indicates heterotetramers with HBB (adult), HBD (A2), HBE1 (embryonic), and HBG2 (fetal). Recombinant production of functional hemoglobin therefore requires coordinated expression of two different globin chains plus heme biosynthesis.

**N-terminal processing:** The initiator methionine is removed in the mature protein (residues 2–142 form the mature chain) [S1](https://www.uniprot.org/uniprotkb/P69905). Recombinant expression systems must account for this processing, or the construct should start at Val2.

**Proteolytic susceptibility:** The alpha chain is cleaved by the hookworm protease Apr-2 at multiple sites (residues 9–10, 14–15, 25–26, 30–31, 46–47) [S1](https://www.uniprot.org/uniprotkb/P69905), which is relevant for production in systems where contaminating proteases may be present.

### pH and Temperature Tolerance

The theoretical pI of 8.717 [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html) indicates that the isolated alpha chain carries a net positive charge at physiological pH 7.4. Hemoglobin's oxygen-binding function is pH-dependent (Bohr effect), but the protein's structural stability across pH ranges is not directly reported in the provided sources. The disease annotation for Heinz body anemias [S1](https://www.uniprot.org/uniprotkb/P69905) notes that variant hemoglobins demonstrate "heat lability," indicating that thermal stability is a clinically relevant parameter that can be compromised by mutations.

### Variant Effects on Stability

The literature sources provide specific examples of how mutations affect stability:

**Hb Tozeur (p.Ala29Pro):** In silico analysis (PolyPhen-2, SIFT, MutationTaster) predicted this variant as deleterious, with structural modeling (Swiss-PdbViewer, DynaMut) indicating destabilization of the alpha-globin protein, reduced stability, and altered flexibility near the heme-binding region [S10](https://europepmc.org/article/MED/40484869).

**Hb I (p.Lys17Glu):** Reported to have "normal stability" and produce no clinical phenotype in heterozygotes [S47](https://europepmc.org/article/MED/42757138), indicating that this substitution is well-tolerated.

**Hb Ariana (230 bp deletion):** Affects the 5'UTR, exon 1, and part of intron 1 of HBA1, leading to reduced alpha-globin synthesis rather than protein instability [S10](https://europepmc.org/article/MED/40484869).

These observations highlight that stability is mutation-specific and that computational predictions (PolyPhen-2, SIFT, DynaMut) can identify destabilizing variants, though experimental validation would be required for quantitative stability measurements.

### Aggregation and Developability

No direct measurements of alpha-globin aggregation propensity were provided in the sources. However, the disease annotation for Heinz body anemias [S1](https://www.uniprot.org/uniprotkb/P69905) describes intracellular inclusions (Heinz bodies) formed by denatured hemoglobin, indicating that destabilized variants can aggregate in erythrocytes. The ESM2 solubility prediction (0.990 probability of soluble) [S30] suggests the wild-type sequence has favorable solubility characteristics, but this prediction does not account for heme loss, oxidative stress, or mutation effects.

### Key Gaps and Limitations

1. **No direct experimental measurements** of melting temperature (Tm), aggregation kinetics, or solubility limits for the recombinant alpha chain were provided in the sources.
2. **Expression host data** (yields, fermentation conditions, purification protocols) were not reported in the supplied evidence.
3. **The ESM2 thermostability score (0.590)** lacks calibration information—the dataset (Thermostability) and score scale are not fully specified, limiting interpretability.
4. **AlphaFold pLDDT** reflects prediction confidence, not experimental stability; the high score (98.06) indicates structural confidence but does not validate folding efficiency or thermodynamic stability.
5. **The isolated alpha chain** is known to be less stable than the tetramer, but quantitative comparisons were not provided in the sources.
6. **The binding site prediction (residues 54–63)** aligns with the heme pocket but was not experimentally validated in this analysis; it should be considered a model prediction consistent with, but not confirming, the annotated heme-binding site.

### Summary

The computed sequence properties (pI 8.717, GRAVY 0.048, instability index 6.97) and ESM2 predictions (high solubility, cytosolic localization, metal binding, moderate thermostability) are consistent with hemoglobin alpha being a soluble, cytosolic, heme-binding protein. Experimental structures confirm the tetrameric assembly and heme coordination. Production of functional recombinant hemoglobin requires addressing heme incorporation, tetramer assembly with beta-like chains, and N-terminal methionine processing. Variant-specific stability effects are clinically significant, as exemplified by the destabilizing Ala29Pro mutation and the thermally labile variants associated with Heinz body anemias. Quantitative biophysical measurements (Tm, aggregation onset, solubility limits) for the recombinant protein remain a gap in the provided evidence.

## 7. Protein engineering & design

### Protein Engineering & Design: Hemoglobin Subunit Alpha (P69905)

### 1. Scope and Sequence Context

This chapter addresses engineering and design studies of human hemoglobin subunit alpha (UniProt P69905, 142 residues including initiator Met). The mature chain spans residues 2–142 after Met1 removal [S1](https://www.uniprot.org/uniprotkb/P69905). Residue numbering throughout follows the full precursor sequence unless noted; many hemoglobin variant databases use mature-chain numbering (residue 1 = mature Val), which is offset by one from the UniProt precursor numbering. The HBA1 and HBA2 genes encode identical mature proteins [S1](https://www.uniprot.org/uniprotkb/P69905). The protein carries one heme b cofactor per subunit, with His88 (proximal) coordinating the iron and His59 implicated in O₂ binding [S1](https://www.uniprot.org/uniprotkb/P69905).

### 2. Natural Variants as a Mutagenesis Resource

The HbVar database (linked from UniProt) catalogs hundreds of naturally occurring alpha-globin variants [S1](https://www.uniprot.org/uniprotkb/P69905). These represent a large-scale "natural mutagenesis" dataset with clinical phenotypes, though most lack quantitative biochemical measurements. Disease associations in UniProt include Heinz body anemias, alpha-thalassemia, and hemoglobin H disease [S1](https://www.uniprot.org/uniprotkb/P69905). The Thionville variant (Val1Glu in mature numbering, retaining acetylated Met) is structurally characterized (PDB 1bab) [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0), demonstrating that natural variants can serve as validated sequence–structure–function reference points.

### 3. Engineered Variants with Structural Characterization

Several engineered alpha-globin variants have been solved by X-ray crystallography, providing experimentally validated structure–function relationships:

**Alpha-chain variants in PDB:**

| Variant | PDB | Chain | Context |
|---------|-----|-------|---------|
| V1M, V62L | 1o1o | A,C | Deoxy Hb, alpha chains |
| T38W (with V1G) | 1gli | C | Deoxy Hb |
| H58L | 3qjd | C | Deoxy form |
| V1M | 1y0t | C | T-to-T(high) transition |
| M Boston (His58Tyr) | 7dy4 | C | Clinical variant |

These structures confirm that N-terminal and internal substitutions are tolerated without disrupting the globin fold, and that position 58 (mature His58 = precursor His59) can be substituted with Tyr (M Boston) or Leu while maintaining crystallizable tetramers [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0). The M Boston variant is a clinical hemoglobin M disease mutant where the proximal histidine is replaced by tyrosine, stabilizing heme iron in the ferric state; its high-resolution structure (7dy4) provides atomic-level detail on how a single substitution alters metal coordination [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0).

The beta-chain mutant structure 1A00 (Valβ1Met, Trpβ37Tyr) [S38](https://www.rcsb.org/structure/1A00) is included for context: it demonstrates that the heterotetramer tolerates paired substitutions across subunits, though the alpha chains in that structure are wild-type.

### 4. Quantitative Measurements and Assay Conditions

The available sources provide structural validation but limited quantitative biophysical measurements. Specific quantitative data include:

- **PDB 1A00**: crystallized at 2.0 Å resolution, 4 heme groups per tetramer, 216 solvent molecules [S38](https://www.rcsb.org/structure/1A00). This provides a baseline for assessing mutant effects on crystal packing and solvent content.
- **Foldseek structural similarity**: the query sequence matches PDB 1bab (Thionville) at 100% sequence identity over 142 residues with evalue 6.24e-21, and 1gli at 98.5% identity over 141 residues [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0). These near-identical matches confirm the variants retain the canonical globin fold.

No direct measurements of oxygen affinity (P50), Hill coefficient, or thermal stability (Tm) for engineered alpha variants were found in the supplied sources. This is a significant gap: the clinical literature on hemoglobin variants (e.g., via HbVar) contains such data for many natural mutants, but those primary measurements are not included here.

### 5. Model Predictions vs. Experimental Evidence

Several computational predictions are available for the wild-type sequence:

**ESM2-650M predictions:**
- Solubility (DeepSol): predicted class 1 (soluble), probability 0.990 [S30]
- Subcellular localization (DeepLocMulti): predicted class 1 (cytoplasmic), probability 0.956 [S31]
- Membrane protein (DeepLocBinary): predicted non-membrane, probability 0.836 [S32]
- Metal ion binding: predicted binder, probability 0.952 [S33]
- Thermostability: predicted stability score 0.590 (scale not defined in source) [S34]
- Sorting signal: predicted class 7 (cytoplasmic), probability 0.721 [S35]

**ProtParam calculations:** molecular weight 15,257.36 Da; theoretical pI 8.72; instability index 6.97 (classified stable, <40); GRAVY 0.048 (slightly hydrophobic); aromaticity 0.078 [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html).

**Comparison with experimental knowledge:**
- The cytoplasmic localization prediction [S31, S35] is consistent with the known red blood cell localization [S1](https://www.uniprot.org/uniprotkb/P69905), though mature erythrocytes lack nuclei and most organelles—the protein is cytosolic.
- The metal-binding prediction [S33] is consistent with heme iron coordination [S1](https://www.uniprot.org/uniprotkb/P69905).
- The solubility prediction [S30] is consistent with hemoglobin's high concentration (~340 mg/mL) in erythrocytes.
- The stability prediction (0.590) has no calibrated threshold in the source; it should not be interpreted as a quantitative ΔG or Tm without validation.

Critically, these predictions are for the wild-type sequence only. None of the supplied model outputs address engineered variants. The Binding Site prediction (VenusX model) flags residues 53–62 (0-indexed positions 52–61) as a putative binding region, which overlaps the experimentally annotated heme/O₂ site at His59 [S1](https://www.uniprot.org/uniprotkb/P69905). This agreement is notable but the model was trained on general protein–ligand interfaces, not specifically heme, so the overlap is suggestive rather than confirmatory.

### 6. Engineering Applications in Non-Hemoglobin Contexts

A 2023 study used canine hemoglobin subunit alpha-like 1 (HBA1) untranslated region (UTR) sequences to optimize mRNA therapeutics [S54](https://europepmc.org/article/MED/37089409). The HBA1 UTR produced the highest GFP fluorescence at 24 h post-transfection among three UTRs tested (HBA1, HBA2, HBB) in canine adipose-derived MSCs. This is an mRNA engineering application that uses globin UTRs for their stability/translation properties—not protein coding-sequence engineering—but it demonstrates that hemoglobin gene elements are exploited in synthetic biology.

### 7. Disease-Associated Variants as Design Constraints

The disease annotations [S1](https://www.uniprot.org/uniprotkb/P69905) indicate that alpha-globin variants can cause:
- **Heinz body anemias**: hemoglobin instability leading to denaturation and precipitation
- **Alpha-thalassemia**: imbalanced globin production
- **Hemoglobin H disease**: loss of three alpha genes

For engineering purposes, these clinical data define a "forbidden zone" of mutations that destabilize the protein or disrupt tetramer assembly. However, the molecular mechanisms (e.g., which specific residues when mutated cause instability) are not quantitatively characterized in the supplied sources.

### 8. Gaps and Recommendations

**Measured data missing:**
- No oxygen affinity (P50), Hill coefficient, or Bohr effect measurements for engineered variants
- No thermal/chemical denaturation curves (ΔG unfolding, Tm)
- No heme binding affinity (Kd) measurements
- No kinetics of tetramer assembly/disassembly

**Prediction limitations:**
- ESM2 predictions are single-sequence, not variant-aware
- No ΔΔG predictions for specific mutations are provided
- The thermostability score (0.590) lacks calibration to experimental units

**Recommended next steps for engineering:**
1. Use HbVar to extract quantitative phenotype data for natural variants at each position
2. Perform alanine scanning mutagenesis around the heme pocket (residues 59–90) with spectroscopic readouts (UV-Vis for heme coordination, circular dichroism for secondary structure)
3. Measure oxygen binding by tonometry or stopped-flow for any designed variant
4. Validate computational stability predictions against the known unstable variants (Heinz body-associated)

### 9. Conclusions

The experimental record for human alpha-globin engineering is dominated by natural variants and a modest set of crystallographically characterized mutants. The fold is remarkably tolerant to substitutions at multiple positions (1, 38, 58, 62), consistent with the high sequence conservation across primates (95–99% identity in Foldseek hits [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0)). The ESM2 predictions for the wild-type sequence align with known biology (cytoplasmic, soluble, metal-binding), but no variant-specific predictions are available. Quantitative engineering of oxygen affinity or stability would require new measurements, as the supplied sources contain structural validation but not biophysical characterization of engineered variants.

## 8. Datasets, applications & reproducibility

### Datasets, Applications & Reproducibility for Human Hemoglobin Subunit Alpha (P69905)

### Scope and Residue Numbering

This chapter covers P69905, the 142-residue human hemoglobin subunit alpha (HBA1/HBA2). UniProt annotations use the full precursor numbering (Met1–Val142), with the mature chain spanning residues 2–142 after initiator methionine removal [S1](https://www.uniprot.org/uniprotkb/P69905). The hemopressin peptide corresponds to residues 96–104 [S1](https://www.uniprot.org/uniprotkb/P69905). All residue positions below follow this UniProt numbering unless otherwise noted. The sequence is shared by HBA1 and HBA2 gene products; P69905 is the canonical reviewed entry.

### Public Sequence and Annotation Datasets

UniProt entry P69905 provides the reference sequence and extensive manually curated annotations [S1](https://www.uniprot.org/uniprotkb/P69905). Key experimentally supported features include: the globin domain (residues 2–142, PROSITE PRU00238), heme b binding at His88 (proximal) and oxygen binding at His59, and the hemopressin peptide (residues 96–104) with cannabinoid receptor CNR1 antagonism demonstrated by PubMed:18077343 [S1](https://www.uniprot.org/uniprotkb/P69905). The initiator methionine removal is supported by four independent publications (PubMed:12665801, 13872627, 13954546, 14093912) [S1](https://www.uniprot.org/uniprotkb/P69905). Disease associations include Heinz body anemias (MIM:140700, PubMed:2833478), alpha-thalassemia (MIM:604131), and hemoglobin H disease (MIM:613978, PubMed:10569720) [S1](https://www.uniprot.org/uniprotkb/P69905).

QuickGO returns 25 annotations (86 total including children) for P69905 [S23](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905). Experimental evidence (IDA, ECO:0000314) supports peroxidase activity (GO:0004601) and haptoglobin binding (GO:0031720) via PMID:19740759. Physical interaction evidence (IPI, ECO:0000353) documents binding to HBB (P68871), AHSP (Q9NZD4), CYB5R3 (P00387), NOS3 (P29474), and multiple keratin and globin partners across 20+ publications [S23](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905). InterPro identifies six entries: the Globin domain (IPR000971), Hemoglobin alpha-type family (IPR002338), Hemoglobin pi family (IPR002339), Globin-like superfamily (IPR009050), Globin/Protoglobin superfamily (IPR012292), and Hemoglobin/oxygen transporter family (IPR050056) [S24](https://www.ebi.ac.uk/interpro/protein/UniProt/P69905/). These annotations are database-derived and should not be conflated with direct experimental measurements.

### Experimental Structure Data

The RCSB PDB contains numerous experimentally determined structures of human hemoglobin. The Foldseek search against PDB100 [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0) identified 40 hits, including 1bab (Hemoglobin Thionville, 100% sequence identity to P69905), 1bz1 (hemoglobin alpha+Met variant, 99.2% identity), 7dy4 (hemoglobin M Boston, 99.2% identity), and multiple deoxy/oxy forms (1gli, 1o1o, 1y0t, 3qjd). These structures span diverse ligation states and mutations, providing experimental ground truth for validating predicted models. The representative structure 1A00 (hemoglobin Valβ1Met, Trpβ37Tyr mutant) was determined by X-ray diffraction at 2.0 Å resolution with 4 heme groups bound, deposited atom count 4770, and 216 solvent atoms [S38](https://www.rcsb.org/structure/1A00). This structure contains two alpha chains (141 residues each) and two beta chains (146 residues each) forming the heterotetramer [S38](https://www.rcsb.org/structure/1A00).

### AlphaFold Model and Structure Predictions

AlphaFold DB contains a predicted structure for P69905 (AF-P69905-F1-model_v6). The InterPro entry confirms the protein is in AlphaFold with continuous coverage from residue 1–142 [S24](https://www.ebi.ac.uk/interpro/protein/UniProt/P69905/). The Foldseek search against afdb-swissprot [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0) returned the self-hit (AF-P69905, 99.2% seqId, score 982, e-value 1.316e-19, full-length 142-residue alignment) and numerous orthologs from primates (Pan paniscus, Pan troglodytes, Gorilla gorilla, Pongo pygmaeus, Macaca mulatta, Chlorocebus aethiops) with sequence identities 89.4–99.2% and near-full-length coverage. These high-scoring ortholog hits reflect the conserved globin fold across primates but do not validate functional properties.

The PDB100 hits from Foldseek provide experimental structure comparisons: 1bab (Thionville variant) achieves score 1039 with 100% sequence identity over full length, while 1gli (deoxyhemoglobin T38W) scores 977 with 98.5% identity over 141 residues [S25](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0). These experimental structures can serve as benchmarks for assessing AlphaFold model quality—a critical comparison given that AlphaFold models are predictions, not experimental determinations.

### ESM2-650M Model Predictions

Six property predictions were generated using ESM2-650M embeddings with task-specific heads [S30–S35, plus activity/binding site predictions]. All predictions share the same input sequence SHA-256 hash (14725a10598943a7aa719eed7d24c7fee599192a6c63c75b051ee6f156341242), confirming identical input.

**Solubility (DeepSol)**: Predicted class 1 (soluble) with probability 0.990 [S30]. This aligns with hemoglobin's known high solubility in erythrocyte cytoplasm, though the model was trained on general protein solubility, not hemoglobin-specific data.

**Subcellular localization (DeepLocMulti)**: Predicted class 1 with probability 0.956 [S31]. The 10-class probability vector shows dominant class 1 (0.956), with minor probabilities spread across other compartments (max 0.024 for class 5). The model's class 1 corresponds to cytoplasm, consistent with hemoglobin's cytosolic localization in red blood cells [S1](https://www.uniprot.org/uniprotkb/P69905).

**Membrane protein (DeepLocBinary)**: Predicted non-membrane (class 1, probability 0.836) [S32]. This is consistent with hemoglobin being a soluble cytosolic protein.

**Metal ion binding (MetalIonBinding)**: Predicted metal-binding (class 1, probability 0.952) [S33]. This is consistent with the experimentally validated heme iron coordination at His88 [S1](https://www.uniprot.org/uniprotkb/P69905).

**Stability (Thermostability)**: Predicted stability score 0.590 [S34]. This is a continuous score where higher values indicate greater predicted thermostability. The moderate value reflects hemoglobin's mesophilic adaptation; no direct experimental melting temperature is provided in the source data.

**Sorting signal**: Predicted class vector [0,0,0,0,0,0,1,0,0] with class 7 probability 0.721 [S35]. The model's class 7 corresponds to cytoplasmic localization, again consistent with experimental knowledge.

**Activity site (VenusX_Res_Act_MP90)**: The model predicts no activity-site residues (all zeros in the 142-position binary vector) [prediction_bf442cdcb535795b]. The per-residue probabilities show the maximum activity-site probability is 0.077 at position 88 (His88), the experimentally validated proximal heme ligand. However, the model's threshold (MP90) classifies all positions as non-activity-site, indicating the model does not recognize hemoglobin's oxygen transport as an "activity" in its training framework.

**Binding site (VenusX_Res_BindI_MP90)**: The model predicts a binding-site region spanning residues 55–64 (10 consecutive residues flagged as binding) [prediction_91a6c34fcabf0333]. This overlaps with the experimentally annotated oxygen-binding residue His59 [S1](https://www.uniprot.org/uniprotkb/P69905). The per-residue probabilities for this region are notably high: position 58 (0.956), 59 (0.970), 60 (0.998), 61 (0.997), 62 (0.997), 63 (0.871), 64 (0.881), 65 (0.833). The prediction correctly identifies the heme pocket region but extends beyond the single experimentally annotated residue, and it misses His88 (probability 0.028 at position 88), the proximal heme ligand. This illustrates that model predictions can partially overlap with experimental annotations while differing in precise boundaries.

### Computed Sequence Properties

ProtParam calculations [S22](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html) provide: molecular weight 15,257.36 Da, theoretical pI 8.717, GRAVY 0.0479, instability index 6.974 (stable), aromaticity 0.0775. Amino acid composition shows high histidine content (10 residues, 7.0%), consistent with hemoglobin's pH-dependent oxygen binding (Bohr effect). The absence of isoleucine (I: 0) is a distinctive feature of human alpha-globin. These are sequence-derived calculations, not experimental measurements.

### Functional Association Networks

STRING [S26](https://string-db.org/cgi/network?identifiers=P69905&species=9606) reports high-confidence functional associations: HBB (score 0.999), HBE1 (0.998), AHSP (0.998), HBA1 (0.998), HBG2 (0.996), HP (0.996), HBG1 (0.994), HBD (0.994), HBQ1 (0.986), CYB5R3 (0.978). The evidence breakdown for HBB shows strong contributions from experiments (escore 0.999), databases (dscore 0.9), and text mining (tscore 0.553). STRING scores represent functional association, not necessarily direct physical binding—a distinction the source itself emphasizes [S26](https://string-db.org/cgi/network?identifiers=P69905&species=9606).

Reactome [S27](https://reactome.org/ContentService/data/mapping/UniProt/P69905/pathways) maps P69905 to six pathways: erythrocyte CO₂ uptake/O₂ release (R-HSA-1237044, R-HSA-1247673), heme scavenging (R-HSA-2168880), HMOX1 cytoprotection (R-HSA-9707564), heme signaling (R-HSA-9707616), and heme assimilation in disease (R-HSA-9927020, disease-annotated).

### Assay Comparability and Evidence Gaps

The experimental and predicted datasets differ fundamentally in evidence type. Experimental structures (X-ray diffraction) provide atomic coordinates with resolution metrics (e.g., 2.0 Å for 1A00) [S38](https://www.rcsb.org/structure/1A00). AlphaFold provides a predicted model without experimental validation metrics in the source data. ESM2-650M predictions provide probabilistic outputs calibrated on training datasets (DeepSol, DeepLoc, etc.) that may not include hemoglobin-specific examples.

Key evidence gaps include: (1) no direct comparison between AlphaFold model coordinates and experimental structures is provided in the source data—such RMSD analysis would require additional computation; (2) the ESM2 activity site model's failure to predict His88 as an activity residue suggests the VenusX training data may not represent oxygen transport as an enzymatic activity; (3) the binding site prediction identifies residues 55–64 but misses His88, indicating the model captures part of the heme pocket but not the full coordination geometry; (4) no deep mutational scanning (DMS) data for P69905 are included in the provided sources, despite the existence of extensive clinical variant databases (HbVar) referenced by UniProt [S1](https://www.uniprot.org/uniprotkb/P69905).

### Reproducible Next Analyses

The following analyses could be reproducibly performed: (1) compute RMSD between AlphaFold AF-P69905-F1 and experimental structures (1bab, 1bz1, 7dy4) using structural alignment tools; (2) benchmark ESM2 binding-site predictions against all experimentally annotated heme-contacting residues from PDB structures; (3) compare ESM2-650M predictions against alternative models (e.g., ProtTrans, ESM-2 15B) for the same six tasks; (4) extract per-residue attention or embedding analyses to understand why the activity-site model misses His88; (5) query HbVar for documented clinical variants and test whether ESM2 predictions differentiate pathogenic from benign substitutions. These analyses would require additional tools and data not present in the current source set.

## Integrated assessment & research priorities

# Executive Synthesis: Human Hemoglobin Subunit Alpha (P69905)

## 1. Cross-Chapter Evidence and Conflict Table

| Topic | Experimental Evidence | Model Predictions | Agreement |
|-------|----------------------|-------------------|-----------|
| **Mature chain length** | 141 aa (Met1 removed), confirmed by 4 publications [S1](https://www.uniprot.org/uniprotkb/P69905) and PDB structures [S38](https://www.rcsb.org/structure/1A00) | AlphaFold covers full 142-residue precursor [S28](https://alphafold.ebi.ac.uk/entry/P69905) | Consistent; models use precursor numbering |
| **Localization** | Red blood cells, cytosolic [S1](https://www.uniprot.org/uniprotkb/P69905) | DeepLocMulti: cytoplasmic (0.956) [S31]; SortingSignal: cytoplasmic (0.721) [S35] | Strong agreement |
| **Solubility** | High solubility in erythrocytes (~340 mg/mL) [S1](https://www.uniprot.org/uniprotkb/P69905) | DeepSol: soluble (0.990) [S30] | Strong agreement |
| **Metal binding** | His88 (proximal heme Fe), His59 (O₂) [S1](https://www.uniprot.org/uniprotkb/P69905); PDB structures with 4 heme groups [S38](https://www.rcsb.org/structure/1A00) | MetalIonBinding: binder (0.952) [S33]; VenusX binding site: residues 55–64 [S37] | Partial: model captures distal pocket but misses His88 |
| **Membrane association** | Soluble, non-membrane [S1](https://www.uniprot.org/uniprotkb/P69905) | DeepLocBinary: non-membrane (0.836) [S32] | Strong agreement |
| **Thermostability** | Heinz body variants are heat-labile [S1](https://www.uniprot.org/uniprotkb/P69905); no Tm measured | Score 0.590 (uncalibrated scale) [S34] | Unverifiable without calibration |
| **Activity site** | Peroxidase and nitrite reductase activities (IDA) [S23](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905) | VenusX: no activity residues predicted [S36] | Discrepancy: model trained on canonical enzymes, not moonlighting functions |
| **Binding site boundaries** | His59 (O₂), His88 (heme Fe) [S1](https://www.uniprot.org/uniprotkb/P69905) | VenusX: residues 55–64 [S37] | Partial overlap; model misses His88, extends beyond His59 |

## 2. Known Unknowns

1. **Functional significance of Ser4 phosphorylation** — detected by mass spectrometry [S1](https://www.uniprot.org/uniprotkb/P69905), but no biological role established.
2. **Mechanism of 3'UTR variant pathogenicity** — HBA1:c.*119_120insT and c.*150C>A predicted to disrupt RNA structure and RBP/miRNA binding [S9](https://europepmc.org/article/MED/41388082), but purely computational.
3. **Hemopressin generation regulation** — conditions governing proteolytic release of residues 96–104 from intact hemoglobin are uncharacterized.
4. **Non-erythroid functions** — QuickGO annotations for peroxidase and nitrite reductase [S23](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905) lack physiological context; keratin interactions [S1](https://www.uniprot.org/uniprotkb/P69905) lack functional validation.
5. **Quantitative biophysics** — no Tm, ΔG unfolding, heme Kd, or P50 measurements for engineered variants in supplied evidence.
6. **Variant-structure mapping** — 714 PDB entries exist [S29](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905), but systematic mapping of disease variants to conformational effects is incomplete.

## 3. Prioritized Experiments with Controls and Measurable Outcomes

### Experiment 1: Functional validation of 3'UTR variants
- **Design**: Clone wild-type and mutant HBA1 3'UTR into luciferase reporter; transfect erythroid (K562) and non-erythroid (HEK293) cells.
- **Controls**: Wild-type 3'UTR; empty vector; β-globin 3'UTR as specificity control.
- **Measurable outcomes**: Relative luciferase activity (normalized to Renilla); mRNA half-life after actinomycin D (hours); RNA pull-down for HuR/AUF1 binding (fold enrichment vs. IgG control).
- **Success criteria**: ≥2-fold reduction in reporter activity and ≥2-fold decrease in mRNA half-life for mutants vs. wild-type.

### Experiment 2: Resolving the binding-site prediction discrepancy
- **Design**: Site-directed mutagenesis of residues 55–64 (alanine scan) and His88; express recombinant alpha-globin with heme supplementation.
- **Controls**: Wild-type alpha-globin; apo-myoglobin as negative control for heme binding.
- **Measurable outcomes**: Heme incorporation (UV-Vis Soret peak at 410 nm); O₂ binding (P50 by tonometry); thermal denaturation (Tm by circular dichroism).
- **Success criteria**: Identify which residues in 55–64 are essential for heme binding (loss of Soret peak); confirm His88 indispensability; compare model-predicted vs. measured essential residues.

### Experiment 3: Phosphorylation functional study
- **Design**: Generate S4A (phospho-null) and S4E (phospho-mimetic) variants; express in erythroid cells.
- **Controls**: Wild-type; empty vector; unrelated phospho-site mutant (e.g., S4A in beta-globin as specificity control).
- **Measurable outcomes**: Tetramer assembly (native PAGE); oxygen affinity (P50); interaction with AHSP (co-immunoprecipitation); erythroid differentiation markers (benzidine staining).
- **Success criteria**: Detectable difference in any measured parameter between S4A/S4E and wild-type.

### Experiment 4: Hemopressin release characterization
- **Design**: Incubate purified hemoglobin with candidate proteases (cathepsin D, calpain, APR-2); quantify hemopressin by LC-MS/MS over time.
- **Controls**: Protease inhibitor cocktail; no-protease incubation; synthetic hemopressin spike for quantification.
- **Measurable outcomes**: Hemopressin yield (pmol/mg hemoglobin/hour); cleavage site mapping by MS/MS.
- **Success criteria**: Identify physiologically relevant protease(s) and conditions for hemopressin generation.

## 4. Reproducibility Recommendations

1. **Numbering convention**: All future analyses must specify precursor (Met1) vs. mature-chain (Val1) numbering. The 1-residue offset causes recurring confusion in variant literature [S1, S10].

2. **Model prediction reporting**: ESM2-650M outputs [S30–S35] should be reported with probability scores, not binary classifications, and never cited as experimental evidence. The thermostability score (0.590) lacks calibration units and should not be compared across proteins.

3. **Structural validation**: AlphaFold AF-P69905-F1 (pLDDT 98.06) [S28](https://alphafold.ebi.ac.uk/entry/P69905) should be validated against experimental structures (1bab, 1bz1, 7dy4) via RMSD calculation before use in downstream analyses. This comparison was not performed in the supplied evidence.

4. **Binding site predictions**: VenusX predictions [S36, S37] should be benchmarked against all heme-contacting residues from the 714 available PDB structures [S29](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905), not just the two annotated histidines.

5. **Variant effect prediction**: In silico pathogenicity tools (PolyPhen-2, SIFT, MutationTaster) used for Hb Tozeur [S10](https://europepmc.org/article/MED/40484869) should be reported with scores and thresholds, and validated against experimental stability measurements before clinical interpretation.

6. **Data provenance**: Distinguish three evidence tiers in all outputs: (a) experimental measurements (X-ray, MS, functional assays), (b) database annotations (UniProt, InterPro, Reactome — curated but not primary), (c) model predictions (AlphaFold, ESM2, ProtParam). Only tier (a) should be described as "confirmed."

## 5. Critical Assessment

The supplied chapters provide a well-integrated synthesis of experimental and predicted data for P69905. The strongest experimental evidence includes 714 PDB structures [S29](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905), 32 IntAct interaction experiments for HBA–HBB [S1](https://www.uniprot.org/uniprotkb/P69905), and multiple independent confirmations of N-terminal processing [S1](https://www.uniprot.org/uniprotkb/P69905). Model predictions align with known biology for localization, solubility, and metal binding, but the VenusX binding-site prediction (residues 55–64) only partially recapitulates the experimentally defined heme coordination (His59, His88), and the activity-site model fails to recognize moonlighting enzymatic functions. These discrepancies highlight that current models capture general biophysical properties but lack the specificity to fully map functional residues in multifunctional proteins. The thermostability score (0.590) is uninterpretable without calibration. The most significant evidence gap is the absence of quantitative biophysical measurements (Tm, Kd, P50) for engineered variants, limiting engineering applications.

## AI model predictions

Model predictions, not experimental measurements. Raw scores from different tasks are not directly comparable.

| Property | Model / dataset | Output |
|---|---|---|
| Solubility | ESM2-650M / DeepSol | [{"predicted_class": "1", "probabilities": "[0.010099989362061024, 0.9899000525474548]"}] |
| Subcellular Localization | ESM2-650M / DeepLocMulti | [{"predicted_class": "1", "probabilities": "[0.00013423534983303398, 0.9559203386306763, 0.004214378073811531, 0.006233572959899902, 0.023536046966910362, 0.005993211176246405, 4.247211109031923e-06, 0.0015076848212629557, 0.0021584942005574703, 0.00029774114955216646]"}] |
| Membrane Protein | ESM2-650M / DeepLocBinary | [{"predicted_class": "1", "probabilities": "[0.1641019731760025, 0.8358980417251587]"}] |
| Metal Ion Binding | ESM2-650M / MetalIonBinding | [{"predicted_class": "1", "probabilities": "[0.04823976010084152, 0.9517602324485779]"}] |
| Stability | ESM2-650M / Thermostability | [{"prediction": "0.590319037437439"}] |
| Sortingsignal | ESM2-650M / SortingSignal | [{"predicted_class": "[0, 0, 0, 0, 0, 0, 1, 0, 0]", "probabilities": "[0.0005463381530717015, 5.252303890301846e-05, 0.00018537203141022474, 0.0050177727825939655, 0.0007102701929397881, 0.06169772148132324, 0.7213419079780579, 0.017041882500052452, 2.023720526267425e-06]"}] |
| Activity Site | ESM2-650M / VenusX_Res_Act_MP90 | [{"predicted_class": "[[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]", "probabilities": "[[[0.994817316532135, 0.005182723980396986], [0.9999581575393677, 4.183028431725688e-05], [0.9997542500495911, 0.00024576776195317507], [0.9999045133590698, 9.552534902468324e-05], [0.9999915361404419, 8.445537787338253e-06], [0.9999977350234985, 2.288578343723202e-06], [0.9999892711639404, 1.0685712368285749e-05], [0.9998795986175537, 0.00012038600834785029], [0.999988317489624, 1.1709083992172964e-05], [0.999981164932251, 1.8864138837670907e-05], [0.9999966621398926, 3.348564177940716e-06], [0.9998517036437988, 0.00014826396363787353], [0.9999984502792358, 1.5066711966937874e-06], [0.9998794794082642, 0.00012047512427670881], [0.9999690055847168, 3.0965980840846896e-05], [0.9998039603233337, 0.000196057735593058 |
| Binding Site | ESM2-650M / VenusX_Res_BindI_MP90 | [{"predicted_class": "[[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]", "probabilities": "[[[0.9990975856781006, 0.0009024183382280171], [0.9999997615814209, 2.761652240224066e-07], [0.9999998807907104, 7.909068244771333e-08], [0.9999195337295532, 8.041631372179836e-05], [0.9999978542327881, 2.1723319605371216e-06], [0.9999971389770508, 2.8607785225176485e-06], [0.9999773502349854, 2.2669652025797404e-05], [0.9988415837287903, 0.00115838588681072], [0.9999110698699951, 8.893731865100563e-05], [0.9999833106994629, 1.6649610188324004e-05], [0.9999978542327881, 2.178676368203014e-06], [0.999893307685852, 0.00010663732246030122], [0.9999350309371948, 6.501044117612764e-05], [0.9999994039535522, 5.368631832425308e-07], [0.9999959468841553, 4.0386207729170565e-06], [0.9904176592826843, 0.009582321159541607], |
| Conserved Site | ESM2-650M / VenusX_Res_Evo_MP90 | No result |
| Motif | ESM2-650M / VenusX_Res_Motif_MP90 | No result |
| Solubility | Ankh-large / DeepSol | No result |
| Subcellular Localization | Ankh-large / DeepLocMulti | No result |
| Membrane Protein | Ankh-large / DeepLocBinary | No result |
| Metal Ion Binding | Ankh-large / MetalIonBinding | No result |
| Stability | Ankh-large / Thermostability | No result |
| Sortingsignal | Ankh-large / SortingSignal | No result |

## Public service results

### NCBI BLAST

pending · 0 results · [Open result](https://blast.ncbi.nlm.nih.gov/Blast.cgi?CMD=Get&RID=E9YNRF3J014)

Job: `E9YNRF3J014`

Still queued at NCBI; open the result link later

### Foldseek server

completed · 40 results · [Open result](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0)

Job: `SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw`

Structural similarity is not evidence of binding, identical function or experimentally validated activity.

Query structure: {"origin": "experimental_structure", "pdb_id": "1bab", "chain": "A", "coverage": 1.0, "resolution": 1.5, "sequence_length": 142, "matches_reference_sequence": false}

| database | target | description | eval | seqId | score |
| --- | --- | --- | --- | --- | --- |
| afdb-swissprot | AF-P69905-F1-model_v6 Hemoglobin subunit alpha | — | 1.316e-19 | 99.2 | 982 |
| afdb-swissprot | AF-P69906-F1-model_v6 Hemoglobin subunit alpha | — | 2.071e-19 | 99.2 | 973 |
| afdb-swissprot | AF-Q9TS35-F1-model_v6 Hemoglobin subunit alpha-1 | — | 2.071e-19 | 97.8 | 972 |
| afdb-swissprot | AF-P69907-F1-model_v6 Hemoglobin subunit alpha | — | 2.533e-19 | 99.2 | 969 |
| afdb-swissprot | AF-P01926-F1-model_v6 Hemoglobin subunit alpha | — | 2.663e-19 | 95.7 | 967 |
| afdb-swissprot | AF-P63107-F1-model_v6 Hemoglobin subunit alpha | — | 2.801e-19 | 96.4 | 966 |
| afdb-swissprot | AF-P63108-F1-model_v6 Hemoglobin subunit alpha | — | 4.633e-19 | 96.4 | 956 |
| afdb-swissprot | AF-P01930-F1-model_v6 Hemoglobin subunit alpha | — | 4.873e-19 | 94.3 | 954 |
| afdb-swissprot | AF-P06635-F1-model_v6 Hemoglobin subunit alpha | — | 5.389e-19 | 97.1 | 954 |
| afdb-swissprot | AF-P67817-F1-model_v6 Hemoglobin subunit alpha | — | 4.873e-19 | 95.7 | 953 |
| afdb-swissprot | AF-P01928-F1-model_v6 Hemoglobin subunit alpha | — | 4.633e-19 | 95 | 953 |
| afdb-swissprot | AF-Q9TS34-F1-model_v6 Hemoglobin subunit alpha-2 | — | 6.267e-19 | 95.7 | 949 |
| afdb-swissprot | AF-P01923-F1-model_v6 Hemoglobin subunit alpha | — | 5.959e-19 | 99.2 | 938 |
| afdb-swissprot | AF-P01939-F1-model_v6 Hemoglobin subunit alpha-B | — | 1.402e-18 | 91.5 | 933 |
| afdb-swissprot | AF-P14387-F1-model_v6 Hemoglobin subunit alpha | — | 1.475e-18 | 89.4 | 929 |
| afdb-swissprot | AF-P19002-F1-model_v6 Hemoglobin subunit alpha-1/2/3 | — | 1.268e-18 | 96.4 | 928 |
| afdb-swissprot | AF-P07421-F1-model_v6 Hemoglobin subunit alpha | — | 8.914e-19 | 95.7 | 927 |
| afdb-swissprot | AF-P67818-F1-model_v6 Hemoglobin subunit alpha | — | 9.375e-19 | 96.4 | 927 |
| afdb-swissprot | AF-P18972-F1-model_v6 Hemoglobin subunit alpha | — | 9.859e-19 | 97.1 | 927 |
| afdb-swissprot | AF-P63112-F1-model_v6 Hemoglobin subunit alpha | — | 2.098e-18 | 91.5 | 927 |
| pdb100 | 1bab-assembly1.cif.gz_A HEMOGLOBIN THIONVILLE: AN ALPHA-CHAIN VARIANT WITH A SUBSTITUTION OF A GLUTAMATE FOR VALINE AT NA-1 AND HAVING AN ACETYLATED METHIONINE NH2 TERMINUS | — | 6.24e-21 | 100 | 1039 |
| pdb100 | 1gli-assembly1.cif.gz_C DEOXYHEMOGLOBIN T38W (ALPHA CHAINS), V1G (ALPHA AND BETA CHAINS) | — | 1.216e-19 | 98.5 | 977 |
| pdb100 | 1o1o-assembly1.cif.gz_A Deoxy hemoglobin (A,C:V1M,V62L; B,D:V1M,V67L) | — | 1.414e-19 | 98.5 | 974 |
| pdb100 | 7dy4-assembly1.cif.gz_C High resolution crystal structure of hemoglobin M Boston. | — | 1.157e-19 | 99.2 | 972 |
| pdb100 | 1bz1-assembly1.cif.gz_A HEMOGLOBIN (ALPHA + MET) VARIANT | — | 1.73e-19 | 99.2 | 972 |
| pdb100 | 1o1o-assembly1.cif.gz_C Deoxy hemoglobin (A,C:V1M,V62L; B,D:V1M,V67L) | — | 1.414e-19 | 98.5 | 971 |
| pdb100 | 1y0t-assembly1.cif.gz_C T-to-T(High) Quaternary Transitions in Human Hemoglobin: betaV1M deoxy low-salt (1 test set) | — | 1.345e-19 | 100 | 971 |
| pdb100 | 3qjd-assembly1.cif.gz_C Human Hemoglobin A Mutant Alpha H58L Deoxy-Form | — | 1.279e-19 | 99.2 | 970 |
| pdb100 | 6bwp-assembly1.cif.gz_C Crystal structure of Deoxy Hemoglobin in complex with beta Cys93 modifying agent, TD3 | — | 1.645e-19 | 100 | 966 |
| pdb100 | 7dy3-assembly1.cif.gz_C High resolution crystal structure of hemoglobin M Iwate. | — | 1.1e-19 | 99.2 | 966 |
| pdb100 | 1hbb-assembly1.cif.gz_C HIGH-RESOLUTION X-RAY STUDY OF DEOXYHEMOGLOBIN ROTHSCHILD 37BETA TRP-&gt; ARG: A MUTATION THAT CREATES AN INTERSUBUNIT CHLORIDE-BINDING SITE | — | 1.73e-19 | 100 | 966 |
| pdb100 | 1y7d-assembly1.cif.gz_C T-To-T(High) quaternary transitions in human hemoglobin: betaP100G deoxy low-salt (1 test set) | — | 2.012e-19 | 100 | 962 |
| pdb100 | 1ye2-assembly1.cif.gz_C T-To-T(High) quaternary transitions in human hemoglobin: betaY35F oxy (2MM IHP, 20% PEG) (1 test set) | — | 2.461e-19 | 100 | 958 |
| pdb100 | 1a3o-assembly1.cif.gz_A ARTIFICIAL MUTANT (ALPHA Y42H) OF DEOXY HEMOGLOBIN | — | 2.461e-19 | 99.2 | 957 |
| pdb100 | 6kai-assembly2.cif.gz_E Crosslinked alpha(Ni)-beta(Fe) human hemoglobin A in the T quaternary structure at 95 K: Light | — | 2.116e-19 | 100 | 957 |
| pdb100 | 1xz5-assembly1.cif.gz_C T-to-THigh Quaternary Transitions in Human Hemoglobin: alphaL91A deoxy low-salt | — | 3.01e-19 | 98.5 | 957 |
| pdb100 | 1vwt-assembly1.cif.gz_C T STATE HUMAN HEMOGLOBIN [ALPHA V96W], ALPHA AQUOMET, BETA DEOXY | — | 2.721e-19 | 99.2 | 956 |
| pdb100 | 1qi8-assembly1.cif.gz_A DEOXYGENATED STRUCTURE OF A DISTAL POCKET HEMOGLOBIN MUTANT | — | 2.862e-19 | 97.8 | 955 |
| pdb100 | 1y4f-assembly1.cif.gz_C T-To-T(High) quaternary transitions in human hemoglobin: betaW37A deoxy low-salt (10 test sets) | — | 3.165e-19 | 100 | 954 |
| pdb100 | 7dy4-assembly2.cif.gz_G High resolution crystal structure of hemoglobin M Boston. | — | 3.165e-19 | 99.2 | 953 |

### InterPro / Pfam

completed · 6 results · [Open result](https://www.ebi.ac.uk/interpro/protein/UniProt/P69905/)

```json
{
  "count": 6,
  "total": 6,
  "entries": [
    {
      "metadata": {
        "accession": "IPR000971",
        "name": "Globin",
        "source_database": "interpro",
        "type": "domain",
        "integrated": null,
        "member_databases": {
          "profile": {
            "PS01033": "Globin domain profile"
          },
          "pfam": {
            "PF00042": "Globin"
          }
        },
        "go_terms": [
          {
            "identifier": "GO:0020037",
            "name": "heme binding",
            "category": {
              "code": "F",
              "name": "molecular_function"
            }
          }
        ]
      },
      "proteins": [
        {
          "accession": "p69905",
          "protein_length": 142,
          "source_database": "reviewed",
          "organism": "9606",
          "in_alphafold": true,
          "entry_protein_locations": [
            {
              "fragments": [
                {
                  "start": 2,
                  "end": 142,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            }
          ]
        }
      ]
    },
    {
      "metadata": {
        "accession": "IPR002338",
        "name": "Hemoglobin, alpha-type",
        "source_database": "interpro",
        "type": "family",
        "integrated": null,
        "member_databases": {
          "cdd": {
            "cd08927": "Hemoglobin alpha, zeta, mu, theta, and related Hb subunits"
          },
          "prints": {
            "PR00612": "ALPHAHAEM"
          }
        },
        "go_terms": [
          {
            "identifier": "GO:0020037",
            "name": "heme binding",
            "category": {
              "code": "F",
              "name": "molecular_function"
            }
          },
          {
            "identifier": "GO:0015671",
            "name": "oxygen transport",
            "category": {
              "code": "P",
              "name": "biological_process"
            }
          },
          {
            "identifier": "GO:0005833",
            "name": "hemoglobin complex",
            "category": {
              "code": "C",
              "name": "cellular_component"
            }
          }
        ]
      },
      "proteins": [
        {
          "accession": "p69905",
          "protein_length": 142,
          "source_database": "reviewed",
          "organism": "9606",
          "in_alphafold": true,
          "entry_protein_locations": [
            {
              "fragments": [
                {
                  "start": 3,
                  "end": 142,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            }
          ]
        }
      ]
    },
    {
      "metadata": {
        "accession": "IPR002339",
        "name": "Hemoglobin, pi",
        "source_database": "interpro",
        "type": "family",
        "integrated": null,
        "member_databases": {
          "prints": {
            "PR00815": "PIHAEM"
          }
        },
        "go_terms": [
          {
            "identifier": "GO:0005506",
            "name": "iron ion binding",
            "category": {
              "code": "F",
              "name": "molecular_function"
            }
          },
          {
            "identifier": "GO:0019825",
            "name": "oxygen binding",
            "category": {
              "code": "F",
              "name": "molecular_function"
            }
          },
          {
            "identifier": "GO:0020037",
            "name": "heme binding",
            "category": {
              "code": "F",
              "name": "molecular_function"
            }
          },
          {
            "identifier": "GO:0015671",
            "name": "oxygen transport",
            "category": {
              "code": "P",
              "name": "biological_process"
            }
          },
          {
            "identifier": "GO:0005833",
            "name": "hemoglobin complex",
            "category": {
              "code": "C",
              "name": "cellular_component"
            }
          }
        ]
      },
      "proteins": [
        {
          "accession": "p69905",
          "protein_length": 142,
          "source_database": "reviewed",
          "organism": "9606",
          "in_alphafold": true,
          "entry_protein_locations": [
            {
              "fragments": [
                {
                  "start": 4,
                  "end": 29,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            },
            {
              "fragments": [
                {
                  "start": 49,
                  "end": 58,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            },
            {
              "fragments": [
                {
                  "start": 73,
                  "end": 83,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            },
            {
              "fragments": [
                {
                  "start": 105,
                  "end": 116,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            }
          ]
        }
      ]
    },
    {
      "metadata": {
        "accession": "IPR009050",
        "name": "Globin-like superfamily",
        "source_database": "interpro",
        "type": "homologous_superfamily",
        "integrated": null,
        "member_databases": {
          "ssf": {
            "SSF46458": "Globin-like"
          }
        },
        "go_terms": null
      },
      "proteins": [
        {
          "accession": "p69905",
          "protein_length": 142,
          "source_database": "reviewed",
          "organism": "9606",
          "in_alphafold": true,
          "entry_protein_locations": [
            {
              "fragments": [
                {
                  "start": 1,
                  "end": 142,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            }
          ]
        }
      ]
    },
    {
      "metadata": {
        "accession": "IPR012292",
        "name": "Globin/Protoglobin",
        "source_database": "interpro",
        "type": "homologous_superfamily",
        "integrated": null,
        "member_databases": {
          "cathgene3d": {
            "G3DSA:1.10.490.10": "Globins"
          }
        },
        "go_terms": [
          {
            "identifier": "GO:0019825",
            "name": "oxygen binding",
            "category": {
              "code": "F",
              "name": "molecular_function"
            }
          },
          {
            "identifier": "GO:0020037",
            "name": "heme binding",
            "category": {
              "code": "F",
              "name": "molecular_function"
            }
          }
        ]
      },
      "proteins": [
        {
          "accession": "p69905",
          "protein_length": 142,
          "source_database": "reviewed",
          "organism": "9606",
          "in_alphafold": true,
          "entry_protein_locations": [
            {
              "fragments": [
                {
                  "start": 2,
                  "end": 142,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            }
          ]
        }
      ]
    },
    {
      "metadata": {
        "accession": "IPR050056",
        "name": "Hemoglobin and related oxygen transporters",
        "source_database": "interpro",
        "type": "family",
        "integrated": null,
        "member_databases": {
          "panther": {
            "PTHR11442": "Hemoglobin and related oxygen transporters"
          }
        },
        "go_terms": null
      },
      "proteins": [
        {
          "accession": "p69905",
          "protein_length": 142,
          "source_database": "reviewed",
          "organism": "9606",
          "in_alphafold": true,
          "entry_protein_locations": [
            {
              "fragments": [
                {
                  "start": 1,
                  "end": 142,
                  "dc-status": "CONTINUOUS"
                }
              ],
              "representative": false,
              "model": null,
              "score": null
            }
          ]
        }
      ]
    }
  ],
  "truncated": false
}
```

### QuickGO

completed · 25 results · [Open result](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905)

```json
{
  "count": 25,
  "total": 86,
  "annotations": [
    {
      "qualifier": "contributes_to",
      "goId": "GO:0004601",
      "goName": null,
      "goEvidence": "IDA",
      "evidenceCode": "ECO:0000314",
      "reference": "PMID:19740759",
      "withFrom": null,
      "taxonId": 9606,
      "assignedBy": "BHF-UCL",
      "symbol": "HBA1"
    },
    {
      "qualifier": "contributes_to",
      "goId": "GO:0031720",
      "goName": null,
      "goEvidence": "IDA",
      "evidenceCode": "ECO:0000314",
      "reference": "PMID:19740759",
      "withFrom": null,
      "taxonId": 9606,
      "assignedBy": "BHF-UCL",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005344",
      "goName": null,
      "goEvidence": "IBA",
      "evidenceCode": "ECO:0000318",
      "reference": "GO_REF:0000033",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "MGI",
              "id": "MGI:96021"
            }
          ]
        },
        {
          "connectedXrefs": [
            {
              "db": "PANTHER",
              "id": "PTN000154218"
            }
          ]
        },
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P69891"
            }
          ]
        },
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P69892"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "GO_Central",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005506",
      "goName": null,
      "goEvidence": "IEA",
      "evidenceCode": "ECO:0000256",
      "reference": "GO_REF:0000002",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "InterPro",
              "id": "IPR002339"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "InterPro",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:10390349",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:10930828",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:11159543",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P02100"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:11724557",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:12072504",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P03129"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "UniProt",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:1552945",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:15550245",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "Q9NZD4"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:15835899",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:16169070",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:23123858",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P00387"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:23123858",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P29474"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:25156257",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "Q9NZD4"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:25416956",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "Q2TAC2"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:25416956",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "Q6A162"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:28665412",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:29997244",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:30833564",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P68871"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:32296183",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "O76011"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:32296183",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P02042"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:32296183",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P02100"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    },
    {
      "qualifier": "enables",
      "goId": "GO:0005515",
      "goName": null,
      "goEvidence": "IPI",
      "evidenceCode": "ECO:0000353",
      "reference": "PMID:32296183",
      "withFrom": [
        {
          "connectedXrefs": [
            {
              "db": "UniProtKB",
              "id": "P09105"
            }
          ]
        }
      ],
      "taxonId": 9606,
      "assignedBy": "IntAct",
      "symbol": "HBA1"
    }
  ],
  "truncated": true
}
```

### STRING

completed · 10 results · [Open result](https://string-db.org/cgi/network?identifiers=P69905&species=9606)

STRING scores combine evidence channels and may represent functional association, not direct physical binding.

```json
{
  "count": 10,
  "species": 9606,
  "partners": [
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000494175",
      "preferredName_A": "HBA2",
      "preferredName_B": "HBB",
      "ncbiTaxonId": 9606,
      "score": 0.999,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0.064,
      "ascore": 0.978,
      "escore": 0.999,
      "dscore": 0.9,
      "tscore": 0.553
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000292896",
      "preferredName_A": "HBA2",
      "preferredName_B": "HBE1",
      "ncbiTaxonId": 9606,
      "score": 0.998,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0.07,
      "ascore": 0.217,
      "escore": 0.982,
      "dscore": 0.9,
      "tscore": 0.336
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000307199",
      "preferredName_A": "HBA2",
      "preferredName_B": "AHSP",
      "ncbiTaxonId": 9606,
      "score": 0.998,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0,
      "ascore": 0.179,
      "escore": 0.964,
      "dscore": 0.9,
      "tscore": 0.498
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000322421",
      "preferredName_A": "HBA2",
      "preferredName_B": "HBA1",
      "ncbiTaxonId": 9606,
      "score": 0.998,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0.048,
      "ascore": 0.978,
      "escore": 0.9,
      "dscore": 0,
      "tscore": 0.448
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000338082",
      "preferredName_A": "HBA2",
      "preferredName_B": "HBG2",
      "ncbiTaxonId": 9606,
      "score": 0.996,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0,
      "ascore": 0.47,
      "escore": 0.935,
      "dscore": 0.9,
      "tscore": 0.137
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000348170",
      "preferredName_A": "HBA2",
      "preferredName_B": "HP",
      "ncbiTaxonId": 9606,
      "score": 0.996,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0,
      "ascore": 0.063,
      "escore": 0.903,
      "dscore": 0.9,
      "tscore": 0.626
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000327431",
      "preferredName_A": "HBA2",
      "preferredName_B": "HBG1",
      "ncbiTaxonId": 9606,
      "score": 0.994,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0.058,
      "ascore": 0.381,
      "escore": 0.9,
      "dscore": 0.9,
      "tscore": 0.218
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000494708",
      "preferredName_A": "HBA2",
      "preferredName_B": "HBD",
      "ncbiTaxonId": 9606,
      "score": 0.994,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0.057,
      "ascore": 0.212,
      "escore": 0.9,
      "dscore": 0.9,
      "tscore": 0.34
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000199708",
      "preferredName_A": "HBA2",
      "preferredName_B": "HBQ1",
      "ncbiTaxonId": 9606,
      "score": 0.986,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0.059,
      "ascore": 0.191,
      "escore": 0.82,
      "dscore": 0.9,
      "tscore": 0.155
    },
    {
      "stringId_A": "9606.ENSP00000251595",
      "stringId_B": "9606.ENSP00000354468",
      "preferredName_A": "HBA2",
      "preferredName_B": "CYB5R3",
      "ncbiTaxonId": 9606,
      "score": 0.978,
      "nscore": 0,
      "fscore": 0,
      "pscore": 0,
      "ascore": 0,
      "escore": 0.458,
      "dscore": 0.9,
      "tscore": 0.633
    }
  ],
  "interpretation": "STRING scores combine evidence channels and may represent functional association, not direct physical binding."
}
```

### Reactome

completed · 6 results · [Open result](https://reactome.org/ContentService/data/mapping/UniProt/P69905/pathways)

```json
{
  "count": 6,
  "total": 6,
  "pathways": [
    {
      "displayName": "Erythrocytes take up carbon dioxide and release oxygen",
      "stId": "R-HSA-1237044",
      "isInDisease": false,
      "isInferred": false,
      "speciesName": "Homo sapiens"
    },
    {
      "displayName": "Erythrocytes take up oxygen and release carbon dioxide",
      "stId": "R-HSA-1247673",
      "isInDisease": false,
      "isInferred": false,
      "speciesName": "Homo sapiens"
    },
    {
      "displayName": "Scavenging of heme from plasma",
      "stId": "R-HSA-2168880",
      "isInDisease": false,
      "isInferred": false,
      "speciesName": "Homo sapiens"
    },
    {
      "displayName": "Cytoprotection by HMOX1",
      "stId": "R-HSA-9707564",
      "isInDisease": false,
      "isInferred": false,
      "speciesName": "Homo sapiens"
    },
    {
      "displayName": "Heme signaling",
      "stId": "R-HSA-9707616",
      "isInDisease": false,
      "isInferred": false,
      "speciesName": "Homo sapiens"
    },
    {
      "displayName": "Heme assimilation",
      "stId": "R-HSA-9927020",
      "isInDisease": true,
      "isInferred": false,
      "speciesName": "Homo sapiens"
    }
  ]
}
```

### AlphaFold DB

completed · 1 results · [Open result](https://alphafold.ebi.ac.uk/entry/P69905)

Predicted structures and pLDDT are not experimental structure or binding validation.

```json
{
  "count": 1,
  "models": [
    {
      "toolUsed": "AlphaFold Monomer v2.0 pipeline",
      "modelEntityId": "AF-P69905-F1",
      "globalMetricValue": 98.06,
      "fractionPlddtVeryLow": 0.0,
      "fractionPlddtLow": 0.007,
      "latestVersion": 6,
      "sequenceStart": 1,
      "sequenceEnd": 142,
      "uniprotAccession": "P69905",
      "cifUrl": "https://alphafold.ebi.ac.uk/files/AF-P69905-F1-model_v6.cif",
      "pdbUrl": "https://alphafold.ebi.ac.uk/files/AF-P69905-F1-model_v6.pdb",
      "paeDocUrl": "https://alphafold.ebi.ac.uk/files/AF-P69905-F1-predicted_aligned_error_v6.json"
    }
  ],
  "interpretation": "Predicted structures and pLDDT are not experimental structure or binding validation."
}
```

### PDBe / PDB

completed · 20 results · [Open result](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905)

```json
{
  "count": 20,
  "total": 714,
  "structures": [
    {
      "pdb_id": "1bab",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.5,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 2,
      "end": 143,
      "coverage": 1.0
    },
    {
      "pdb_id": "1bab",
      "chain_id": "C",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.5,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 2,
      "end": 143,
      "coverage": 1.0
    },
    {
      "pdb_id": "1bz1",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.59,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "1bz1",
      "chain_id": "C",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.59,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7qu4",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.66,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7qu4",
      "chain_id": "B",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.66,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7ud7",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.8,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7ud7",
      "chain_id": "C",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.8,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7ud8",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.8,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7ud8",
      "chain_id": "C",
      "experimental_method": "X-ray diffraction",
      "resolution": 1.8,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7uf6",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 2.0,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7uf6",
      "chain_id": "C",
      "experimental_method": "X-ray diffraction",
      "resolution": 2.0,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7uf7",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 2.0,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "7uf7",
      "chain_id": "C",
      "experimental_method": "X-ray diffraction",
      "resolution": 2.0,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "8vyl",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 2.02,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "8vyl",
      "chain_id": "C",
      "experimental_method": "X-ray diffraction",
      "resolution": 2.02,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "8wj0",
      "chain_id": "A",
      "experimental_method": "Electron Microscopy",
      "resolution": 2.24,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "9vib",
      "chain_id": "A",
      "experimental_method": "Electron Microscopy",
      "resolution": 2.26,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "8wj1",
      "chain_id": "A",
      "experimental_method": "Electron Microscopy",
      "resolution": 2.27,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    },
    {
      "pdb_id": "6kye",
      "chain_id": "A",
      "experimental_method": "X-ray diffraction",
      "resolution": 2.28,
      "tax_id": 9606,
      "unp_start": 1,
      "unp_end": 142,
      "start": 1,
      "end": 142,
      "coverage": 1.0
    }
  ],
  "truncated": true
}
```

## Sources

- [S1 · UniProt · P69905 · Hemoglobin subunit alpha](https://www.uniprot.org/uniprotkb/P69905) · database_annotation

- [S2 · [Rapid detection of the common alpha-thalassemia-2 determinants by PCR assay].](https://europepmc.org/article/MED/11402454) · abstract

- [S3 · Alpha2(CD31 AGG-->AAG, Arg-->Lys) causing non-deletional alpha-thalassemia in a Chinese family with HbH disease.](https://europepmc.org/article/MED/11410421) · abstract

- [S4 · Mutation in an intervening sequence splice junction in man.](https://europepmc.org/article/MED/6946451) · abstract

- [S5 · Cloning and complete nucleotide sequence of human 5'-alpha-globin gene.](https://europepmc.org/article/MED/6452630) · abstract

- [S6 · The 3' untranslated regions of the duplicated human alpha-globin genes are unexpectedly divergent.](https://europepmc.org/article/MED/7448866) · abstract

- [S7 · Nucleotide sequence of the coding portion of human alpha globin messenger RNA.](https://europepmc.org/article/MED/6244294) · abstract

- [S8 · An Integrated Genotyping Strategy for α/β-Thalassemia: Based on the Analysis of the Coding Sequences and Expression Levels of HBA2, HBA1, and HBB in Peripheral Blood mRNA.](https://europepmc.org/article/MED/41735777) · abstract

- [S9 · Importance of the 3'UTR region in globin synthesis: identification of two novel HBA1 mutations causing α-Thalassemia.](https://europepmc.org/article/MED/41388082) · abstract

- [S10 · Revealing silent alpha-thalassemia: characterization of novel HBA1 deletion and missense mutation in Tunisian families.](https://europepmc.org/article/MED/40484869) · abstract

- [S11 · Activated partial thromboplastin time prolongation without hemorrhagic dienhesis: a study of a chinese family coexisting with hereditary KNG1 p.Arg240 mutation and --SEA/αα genotype thalassemia.](https://europepmc.org/article/MED/41634406) · abstract

- [S12 · NFκB1: a common biomarker linking Alzheimer's and Parkinson's disease pathology.](https://europepmc.org/article/MED/40395692) · abstract

- [S13 · Genetic profiles and hematological characteristics of the α-Hb variant Hb Chumphae (HBA2:c.32T>A) in association with -<sup>SEA</sup> deletion α<sup>0</sup>-thalassemia.](https://europepmc.org/article/MED/42526165) · abstract

- [S14 · Structural Variants in the Human Genome Associated With Gut Microbiome and Blood Metabolic Traits With Potential Causal Links.](https://europepmc.org/article/MED/42860521) · abstract

- [S15 · Fecal HBA mRNA as an alternative to FIT for colorectal cancer screening: a computational and clinical validation study.](https://europepmc.org/article/MED/42067576) · abstract

- [S16 · Understanding the Nuances of HBA Peptide Research](https://cetaf.org/hba-peptide-base) · search_extract

- [S17 · UniProt](https://www.uniprot.org/uniprotkb/P69905/variant-viewer) · search_extract

- [S18 · Hemoglobin subunit alpha - Wikipedia](https://en.wikipedia.org/wiki/Hemoglobin_subunit_alpha) · search_extract

- [S19 · HBA1 gene: MedlinePlus Genetics](https://medlineplus.gov/genetics/gene/hba1) · search_extract

- [S20 · Hemoglobin Variants: Biochemical Properties and Clinical Correlates](https://pmc.ncbi.nlm.nih.gov/articles/PMC3579210) · search_extract

- [S21 · UniProt](https://www.uniprot.org/uniprotkb/P69905/entry) · search_extract

- [S22 · Sequence properties · Biopython ProtParam](https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html) · computed

- [S23 · QuickGO · public analysis](https://www.ebi.ac.uk/QuickGO/annotations?geneProductId=P69905) · database_annotation

- [S24 · InterPro / Pfam · public analysis](https://www.ebi.ac.uk/interpro/protein/UniProt/P69905/) · database_annotation

- [S25 · Foldseek server · public analysis](https://search.foldseek.com/result/SLF9dezByoKCDCQqu4fxEEI3qtU6WjwwHFZmpw/0) · structure_similarity

- [S26 · STRING · public analysis](https://string-db.org/cgi/network?identifiers=P69905&species=9606) · functional_association

- [S27 · Reactome · public analysis](https://reactome.org/ContentService/data/mapping/UniProt/P69905/pathways) · database_annotation

- [S28 · AlphaFold DB · public analysis](https://alphafold.ebi.ac.uk/entry/P69905) · model_prediction

- [S29 · PDBe / PDB · public analysis](https://www.ebi.ac.uk/pdbe/api/mappings/best_structures/P69905) · experimental_structure_metadata

- [S38 · RCSB PDB 1A00 · HEMOGLOBIN (VAL BETA1 MET, TRP BETA37 TYR) MUTANT](https://www.rcsb.org/structure/1A00) · experimental_structure_metadata

- [S39 · RCSB PDB 1A01 · HEMOGLOBIN (VAL BETA1 MET, TRP BETA37 ALA) MUTANT](https://www.rcsb.org/structure/1A01) · experimental_structure_metadata

- [S40 · RCSB PDB 1A0U · HEMOGLOBIN (VAL BETA1 MET) MUTANT](https://www.rcsb.org/structure/1A0U) · experimental_structure_metadata

- [S41 · Integrated analysis of DNA methylation and gene expression in dairy cows during early pregnancy.](https://europepmc.org/article/MED/41527033) · abstract

- [S42 · Placental iron utilisation in fetal growth restriction: alterations in mitochondrial haem synthesis and iron-sulphur cluster assembly pathways.](https://europepmc.org/article/MED/41697720) · abstract

- [S43 · Proteome expression profiling of red blood cells during the tumorigenesis of hepatocellular carcinoma.](https://europepmc.org/article/MED/36346805) · abstract

- [S44 · RCSB PDB - AF_AFP69905F1: Computed structure model of Hemoglobin subunit alpha](https://www.rcsb.org/structure/AF_AFP69905F1) · search_extract

- [S45 · Human Gene HBA1 (ENST00000320868.9_4) from ...](https://genome.ucsc.edu/cgi-bin/hgGene?db=hg19&hgg_gene=HBA1) · search_extract

- [S46 · hemoglobin subunit alpha 1 - NCBI - NLM - NIH](https://www.ncbi.nlm.nih.gov/datasets/gene/3039) · search_extract

- [S47 · Abnormally Low Hemoglobin A1c Due to a Heterozygous Alpha-Globin Variant (Hb I; HBA2 c.49A>G, p.Lys17Glu) in a Geriatric Patient.](https://europepmc.org/article/MED/42757138) · abstract

- [S48 · Transcriptome analysis of serum biomarker, shared gene signature and pharmacological targets between diabetic cardiomyopathy and nephropathy.](https://europepmc.org/article/MED/40800606) · abstract

- [S49 · Extracellular Vesicle Protein and MiRNA Signatures as Biomarkers for Post-Infectious ME/CFS Patients.](https://europepmc.org/article/MED/41828537) · abstract

- [S50 · Small Angle Scattering Biological Data Bank SASBDB](https://www.sasbdb.org/uniprot/P69905) · search_extract

- [S51 · Hb Baise (<i>HBA2</i>: C.153_154insGACCTG): An Unexpectedly Discovered Novel Variant in Glycated Hemoglobin Testing.](https://europepmc.org/article/MED/42124420) · abstract

- [S52 · UniProt](https://www.uniprot.org/uniprotkb/P69905/publications) · search_extract

- [S53 · Digoxin Attenuates Ocular Hypertension and Protects Trabecular Meshwork Cells via Ferroptosis Inhibition.](https://europepmc.org/article/MED/41563015) · abstract

- [S54 · Canine adipose tissue-derived MSCs engineered with mRNA to overexpress TSG-6 and enhance the anti-inflammatory effects in canine macrophages.](https://europepmc.org/article/MED/37089409) · abstract

- [S55 · Integrated proteomic and lipidomic analysis revealed potential plasma biomarkers for cervical cancer.](https://europepmc.org/article/MED/40882533) · abstract

- [S56 · Engineered mRNA backbones for gene expression in human T cells.](https://europepmc.org/article/MED/42028577) · abstract

- [S57 · Validation of Gazelle Microchip Electrophoresis for Premarital Hemoglobinopathy Screening in Türkiye.](https://europepmc.org/article/MED/42253629) · abstract

- [S58 · Hemoglobin subunit alpha](https://www.receptor.ai/proteins/p69905) · search_extract

- [S59 · HBA1 | Homo sapiens gene](https://www.alliancegenome.org/gene/HGNC:4823) · search_extract