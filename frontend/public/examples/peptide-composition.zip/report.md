# Peptide Amino-Acid Composition Calculator — Report

## 1. Objective

Develop a reusable peptide amino-acid composition calculator as a fresh, bounded
software-tool project. The scope is strictly computational: implement
`calculate_composition(sequence)` with standard-amino-acid validation, sequence
length, and residue fractions; verify with the two synthetic sequences
`ACDEFGHIK` and `GGGSS`; and include at least 16 meaningful test assertions
covering normal and invalid inputs. No downloads, wet-lab measurements, or
biological performance claims are made.

## 2. Implementation

`peptide_composition.py` provides `calculate_composition(sequence)` which:

- Validates that the input is a string (`TypeError` otherwise).
- Validates that the string is non-empty (`ValueError`).
- Validates that every character is one of the 20 standard amino-acid letters
  `ACDEFGHIKLMNPQRSTVWY` (`ValueError` otherwise). This rejects lowercase,
  whitespace, non-ASCII, and non-standard characters.
- Returns a dictionary with:
  - `sequence`: the validated input string
  - `length`: number of residues
  - `composition`: mapping of each residue present to its fraction (count/length)

## 3. Measured Results

### Composition results (`composition_results.json`)

| Sequence | Length | Composition |
|----------|--------|-------------|
| `ACDEFGHIK` | 9 | Each of A,C,D,E,F,G,H,I,K = 1/9 ≈ 0.1111 |
| `GGGSS` | 5 | G = 0.6, S = 0.4 |

### Test results (`composition_test_results.json`)

- **Total tests:** 19
- **Passed:** 19
- **Failed:** 0

The 19 assertions cover:

- Valid sequence `ACDEFGHIK`: length, all residues present, each fraction = 1/9,
  fractions sum to 1, sequence echoed.
- Valid sequence `GGGSS`: length, G fraction = 0.6, S fraction = 0.4, fractions
  sum to 1, duplicate residue counts.
- Single residue `A`.
- Invalid inputs: empty string, non-string (int), `None`, invalid character `X`,
  lowercase, mixed case, whitespace, non-ASCII character.

All tests passed when executed in the sandbox (`exit_code = 0`).

## 4. Development / Revision Decisions

- **Validation strictness:** The validator rejects any character outside the 20
  standard amino acids. This is intentionally strict so that ambiguous codes
  (e.g. `X`, `B`, `Z`, `J`) and lowercase letters are rejected rather than
  silently counted. This matches the stated requirement of "standard-amino-acid
  input validation".
- **Return format:** A nested dictionary with `sequence`, `length`, and
  `composition` was chosen to be self-describing and easy to serialize to JSON.
- **Fractions:** Fractions are computed as `count / length` and are therefore
  exact rational values represented as floats. The test suite uses approximate
  comparison with a tolerance of `1e-9`.
- **No dependencies:** The implementation uses only the Python standard library,
  so `requirements.txt` lists no third-party packages.

## 5. Scope and Limitations

- **Scope:** This tool computes amino-acid composition for one-letter upper-case
  sequences of the 20 standard amino acids. It is intended for simple
  compositional analysis and educational/demonstration purposes.
- **Limitations:**
  - It does not handle ambiguous amino-acid codes (`X`, `B`, `Z`, `J`, `U`, `O`).
  - It does not accept lowercase input (case-sensitive by design).
  - It does not compute molecular weight, pI, GRAVY, or other physicochemical
    properties.
  - It makes no biological performance claims and was not validated against any
    wet-lab measurements.
  - Only two synthetic sequences were used for verification; broader validation
    would require additional test data.

## 6. Reproduction

```bash
python generate_composition_results.py
python test_peptide_composition.py
```

Both commands run with Python 3.7+ and no third-party dependencies.

## 7. Conclusion

The project is complete: the implementation, tests, measured result JSON files,
README, requirements, and report are all present and consistent. All 19 test
assertions pass. The tool is a reusable, dependency-free utility suitable for
simple peptide composition analysis within the stated scope.