"""Generate composition_results.json for the two synthetic sequences."""

import json

from peptide_composition import calculate_composition

SEQUENCES = ["ACDEFGHIK", "GGGSS"]

results = {
    "tool": "peptide_composition.calculate_composition",
    "version": "1.0.0",
    "description": "Measured amino-acid composition for synthetic test sequences.",
    "sequences": [],
}

for seq in SEQUENCES:
    comp = calculate_composition(seq)
    results["sequences"].append(comp)

with open("composition_results.json", "w", encoding="utf-8") as fh:
    json.dump(results, fh, indent=2)

print("Wrote composition_results.json")
print(json.dumps(results, indent=2))