"""Peptide amino-acid composition calculator.

This module provides a small, dependency-free utility to compute the amino-acid
composition of a peptide/protein sequence given as a one-letter string.

Scope
-----
- Input: a Python string containing only the 20 standard amino-acid letters
  (ACDEFGHIKLMNPQRSTVWY), in upper case.
- Output: a dictionary with the sequence length and the fraction of each
  residue present in the sequence.
- Validation: raises ValueError for non-string input, empty strings, lowercase
  letters, whitespace, non-ASCII characters, or any character outside the
  standard 20 amino acids.

This is a purely computational tool. It makes no biological performance claims.
"""

# The 20 standard amino acids in one-letter code.
STANDARD_AMINO_ACIDS = frozenset("ACDEFGHIKLMNPQRSTVWY")


def calculate_composition(sequence):
    """Return sequence length and per-residue fractions for a peptide sequence.

    Parameters
    ----------
    sequence : str
        A non-empty string of upper-case one-letter codes for the 20 standard
        amino acids (e.g. "ACDEFGHIK").

    Returns
    -------
    dict
        A dictionary with keys:
          "sequence" : the validated input sequence
          "length"   : int, number of residues
          "composition" : dict mapping each residue letter present in the
                          sequence to its fraction (count / length)

    Raises
    ------
    TypeError
        If `sequence` is not a string.
    ValueError
        If `sequence` is empty, contains lowercase letters, whitespace,
        non-ASCII characters, or any character outside the standard 20 amino
        acids.
    """
    if not isinstance(sequence, str):
        raise TypeError("sequence must be a string, got %s" % type(sequence).__name__)

    if len(sequence) == 0:
        raise ValueError("sequence must not be empty")

    invalid = sorted(set(sequence) - STANDARD_AMINO_ACIDS)
    if invalid:
        raise ValueError(
            "sequence contains non-standard amino-acid character(s): %s"
            % ", ".join(repr(c) for c in invalid)
        )

    length = len(sequence)
    counts = {}
    for residue in sequence:
        counts[residue] = counts.get(residue, 0) + 1

    composition = {
        residue: count / length
        for residue, count in sorted(counts.items())
    }

    return {
        "sequence": sequence,
        "length": length,
        "composition": composition,
    }