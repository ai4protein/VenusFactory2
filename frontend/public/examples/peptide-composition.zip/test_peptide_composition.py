"""Tests for peptide_composition.calculate_composition.

This test module verifies normal behaviour on the two synthetic sequences
ACDEFGHIK and GGGSS, and verifies input validation for a range of invalid
inputs. It contains at least 16 meaningful assertions.
"""

import json
import math
import os

from peptide_composition import calculate_composition


def approx(a, b, tol=1e-9):
    """Return True if a and b are approximately equal."""
    return abs(a - b) <= tol


def test_acdefghik_length():
    result = calculate_composition("ACDEFGHIK")
    assert result["length"] == 9


def test_acdefghik_all_residues_present():
    result = calculate_composition("ACDEFGHIK")
    assert set(result["composition"].keys()) == set("ACDEFGHIK")


def test_acdefghik_each_fraction():
    result = calculate_composition("ACDEFGHIK")
    for residue in "ACDEFGHIK":
        assert approx(result["composition"][residue], 1.0 / 9.0)


def test_acdefghik_fractions_sum_to_one():
    result = calculate_composition("ACDEFGHIK")
    assert approx(sum(result["composition"].values()), 1.0)


def test_acdefghik_sequence_echoed():
    result = calculate_composition("ACDEFGHIK")
    assert result["sequence"] == "ACDEFGHIK"


def test_gggss_length():
    result = calculate_composition("GGGSS")
    assert result["length"] == 5


def test_gggss_g_fraction():
    result = calculate_composition("GGGSS")
    assert approx(result["composition"]["G"], 3.0 / 5.0)


def test_gggss_s_fraction():
    result = calculate_composition("GGGSS")
    assert approx(result["composition"]["S"], 2.0 / 5.0)


def test_gggss_fractions_sum_to_one():
    result = calculate_composition("GGGSS")
    assert approx(sum(result["composition"].values()), 1.0)


def test_single_residue():
    result = calculate_composition("A")
    assert result["length"] == 1
    assert approx(result["composition"]["A"], 1.0)


def test_empty_raises():
    try:
        calculate_composition("")
    except ValueError:
        pass
    else:
        raise AssertionError("empty sequence should raise ValueError")


def test_non_string_raises():
    try:
        calculate_composition(12345)
    except TypeError:
        pass
    else:
        raise AssertionError("non-string input should raise TypeError")


def test_none_raises():
    try:
        calculate_composition(None)
    except TypeError:
        pass
    else:
        raise AssertionError("None input should raise TypeError")


def test_invalid_character_raises():
    try:
        calculate_composition("ACDEFGHIKX")  # X is not a standard amino acid
    except ValueError:
        pass
    else:
        raise AssertionError("X should raise ValueError")


def test_lowercase_raises():
    try:
        calculate_composition("acdefghik")
    except ValueError:
        pass
    else:
        raise AssertionError("lowercase should raise ValueError")


def test_mixed_case_raises():
    try:
        calculate_composition("ACdefGHIK")
    except ValueError:
        pass
    else:
        raise AssertionError("mixed case should raise ValueError")


def test_whitespace_raises():
    try:
        calculate_composition("ACD EFGHIK")
    except ValueError:
        pass
    else:
        raise AssertionError("whitespace should raise ValueError")


def test_non_ascii_raises():
    try:
        calculate_composition("ACD\u00e9FGHIK")  # é is non-ASCII
    except ValueError:
        pass
    else:
        raise AssertionError("non-ASCII should raise ValueError")


def test_duplicate_residue_counts():
    result = calculate_composition("GGGSS")
    assert result["composition"]["G"] == 0.6
    assert result["composition"]["S"] == 0.4


def run_all():
    """Run every test function, collect results, and write JSON outputs."""
    test_functions = [
        test_acdefghik_length,
        test_acdefghik_all_residues_present,
        test_acdefghik_each_fraction,
        test_acdefghik_fractions_sum_to_one,
        test_acdefghik_sequence_echoed,
        test_gggss_length,
        test_gggss_g_fraction,
        test_gggss_s_fraction,
        test_gggss_fractions_sum_to_one,
        test_single_residue,
        test_empty_raises,
        test_non_string_raises,
        test_none_raises,
        test_invalid_character_raises,
        test_lowercase_raises,
        test_mixed_case_raises,
        test_whitespace_raises,
        test_non_ascii_raises,
        test_duplicate_residue_counts,
    ]

    results = []
    passed = 0
    failed = 0
    for fn in test_functions:
        try:
            fn()
            status = "PASS"
            passed += 1
            error = None
        except AssertionError as exc:
            status = "FAIL"
            failed += 1
            error = str(exc)
        except Exception as exc:  # pragma: no cover - defensive
            status = "ERROR"
            failed += 1
            error = "%s: %s" % (type(exc).__name__, exc)
        results.append(
            {
                "test": fn.__name__,
                "status": status,
                "error": error,
            }
        )

    summary = {
        "total_tests": len(test_functions),
        "passed": passed,
        "failed": failed,
        "results": results,
    }

    with open("composition_test_results.json", "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)

    print("Test summary: %d total, %d passed, %d failed"
          % (len(test_functions), passed, failed))
    for r in results:
        print("  %-40s %s" % (r["test"], r["status"]))
        if r["error"]:
            print("    -> %s" % r["error"])

    return summary


def main():
    summary = run_all()
    if summary["failed"] != 0:
        raise SystemExit(1)


if __name__ == "__main__":
    main()