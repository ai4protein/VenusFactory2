# Peptide Amino-Acid Composition Calculator

A small, dependency-free Python utility that computes the amino-acid composition
of a peptide/protein sequence given as a one-letter string.

## Goal

Provide a reusable `calculate_composition(sequence)` function that:

- Validates input (must be a non-empty string containing only the 20 standard
  amino-acid letters `ACDEFGHIKLMNPQRSTVWY` in upper case).
- Returns the sequence length and the fraction of each residue present.
- Raises clear errors for invalid input (non-string, empty, lowercase,
  whitespace, non-ASCII, or non-standard characters).

This is a purely computational tool. It makes no biological performance claims.

## Files

| File | Description |
|------|-------------|
| `peptide_composition.py` | Core implementation of `calculate_composition`. |
| `test_peptide_composition.py` | Test suite (19 assertions) covering normal and invalid inputs. |
| `generate_composition_results.py` | Generates `composition_results.json` for the two synthetic sequences. |
| `composition_results.json` | Measured composition for `ACDEFGHIK` and `GGGSS`. |
| `composition_test_results.json` | Test counts, pass/fail status and measured outcomes. |
| `requirements.txt` | Dependency list (no runtime dependencies). |
| `report.md` | English report documenting results, decisions, scope and limitations. |

## Requirements

- Python 3.7+
- No third-party packages are required.

## Exact runnable commands

```bash
# 1. Generate composition results for the two synthetic sequences
python generate_composition_results.py

# 2. Run the test suite (19 assertions)
python test_peptide_composition.py

# 3. (Optional) Use the calculator interactively
python -c "from peptide_composition import calculate_composition; print(calculate_composition('ACDEFGHIK'))"
```

## Example output

```python
>>> from peptide_composition import calculate_composition
>>> calculate_composition("ACDEFGHIK")
{'sequence': 'ACDEFGHIK', 'length': 9,
 'composition': {'A': 0.111..., 'C': 0.111..., ...}}
```

## License / Scope

This is a demonstration software-tool project using synthetic sequences only.
No downloads, wet-lab measurements, or biological performance claims are made.