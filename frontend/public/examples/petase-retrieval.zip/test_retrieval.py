#!/usr/bin/env python3
"""Integration test: verify record.json contains a real NCBI protein accession.

This test only validates software integration (retrieval + persistence + JSON
parsing). It makes no biological measurements or model claims.
"""

import json
import os
import re
import sys

RECORD_PATH = os.path.join(os.path.dirname(__file__), "record.json")


def main():
    # 1. File exists and is readable
    assert os.path.isfile(RECORD_PATH), f"record.json not found at {RECORD_PATH}"
    with open(RECORD_PATH, "r", encoding="utf-8") as fh:
        raw = fh.read()
    assert len(raw) > 0, "record.json is empty"

    # 2. Valid JSON
    data = json.loads(raw)
    assert isinstance(data, dict), "record.json root must be a JSON object"

    # 3. Non-empty records list
    records = data.get("records", [])
    assert isinstance(records, list) and len(records) > 0, "records must be a non-empty list"

    # 4. Real accession string matching NCBI protein accession patterns.
    #    Common NCBI/UniProt protein accession formats include:
    #      - UniProt/Swiss-Prot style: D4Q9N1, P12345, A0A1B2C3D4
    #      - NCBI RefSeq style: NP_123456, XP_012345678
    #      - GenBank style: ABC12345, AAA12345.1
    #    All start with a letter and contain digits (and optionally underscores).
    accession = records[0].get("caption", "")
    accession_version = records[0].get("accessionversion", "")
    assert isinstance(accession, str) and len(accession) > 0, "caption/accession is empty"

    # Broad but meaningful NCBI protein accession pattern:
    #   - starts with a letter
    #   - contains at least one digit
    #   - may contain underscores (RefSeq) and an optional version suffix
    accession_pattern = re.compile(r"^[A-Za-z][A-Za-z0-9_]*\d[A-Za-z0-9_]*$")
    assert accession_pattern.match(accession), (
        f"accession '{accession}' does not match common NCBI protein accession pattern "
        "(starts with a letter and contains digits)"
    )
    assert accession_version.startswith(accession), (
        f"accessionversion '{accession_version}' should start with '{accession}'"
    )

    # 5. Record has a source URL (provenance)
    sources = data.get("sources", [])
    assert isinstance(sources, list) and len(sources) > 0, "sources must be non-empty"
    assert "url" in sources[0], "source URL missing"

    print("PASS: record.json is valid JSON and contains a real NCBI protein accession.")
    print(f"  accession       : {accession}")
    print(f"  accessionversion: {accession_version}")
    print(f"  organism        : {records[0].get('organism', 'N/A')}")
    print(f"  source          : {sources[0].get('url', 'N/A')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())