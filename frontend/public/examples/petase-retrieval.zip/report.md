# Integration Verification Report

## Objective

Bounded software integration verification: confirm that the `query_ncbi` tool
can retrieve a real public NCBI protein record for PETase, that the raw output
can be persisted as JSON, and that a local Python test can validate the
retrieved accession. This is **not** a protein-model development task.

## What Was Done

1. **Retrieval (Step 1)**
   - Tool: `query_ncbi(database="protein", action="search", query="PETase", limit=1)`
   - Result: returned 1 record (total 5167 matches for PETase in NCBI protein).
   - Accession: **D4Q9N1** (accession version `D4Q9N1.2`)
   - Organism: *Thermobifida alba*
   - Source: https://www.ncbi.nlm.nih.gov/protein/?term=PETase
   - The raw tool output was saved verbatim as `record.json`.

2. **Validation (Step 2)**
   - Test file: `test_retrieval.py`
   - Assertions:
     - `record.json` exists and is readable.
     - `record.json` is valid JSON.
     - The `records` list is non-empty.
     - The accession (`caption`) is a non-empty string starting with a letter
       and containing digits (matching common NCBI protein accession patterns).
     - `accessionversion` starts with the accession.
     - A source URL is present (provenance).
   - Result: **PASS** (exit code 0).

   ```
   PASS: record.json is valid JSON and contains a real NCBI protein accession.
     accession       : D4Q9N1
     accessionversion: D4Q9N1.2
     organism        : Thermobifida alba
     source          : https://www.ncbi.nlm.nih.gov/protein/?term=PETase
   ```

3. **Documentation (Step 3)**
   - `README.md` with exact reproduction commands.
   - `test_retrieval.py` included.
   - `requirements.txt` states no third-party dependencies are needed.
   - This `report.md` documents the results.

## Explicit Non-Claims

- No biological measurements were made or inferred.
- No model was trained, registered, or proposed.
- No solubility or enzymatic-activity claim is made.
- The retrieved accession is used solely to verify software integration
  (retrieval → persistence → validation).

## Artifacts

| File                | SHA-256                                                           |
|---------------------|-------------------------------------------------------------------|
| `record.json`       | `61ebffc4b6a17d32e05530d699bcea208c3286b0352dc091d9b144988613a814` |
| `test_retrieval.py` | `46ff0f7c785f86efc02702566b01df86aa147423d8a4a261903e1ffd27776100` |
| `README.md`         | (written in this session)                                         |
| `requirements.txt`  | (written in this session)                                         |
| `report.md`         | (this file)                                                       |

## Conclusion

The end-to-end pipeline **passed**: a real public NCBI protein accession
(`D4Q9N1`) was retrieved, persisted as `record.json`, and validated by
`test_retrieval.py` with exit code 0. All three plan steps are complete.