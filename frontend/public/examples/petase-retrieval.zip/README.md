# PETase NCBI Retrieval — Integration Verification

This project verifies software integration only: retrieving a real public NCBI
protein record for PETase, persisting the raw tool output, and validating it
with a local test. **No biological measurements, model training, or solubility
claims are made.**

## Files

| File                | Purpose                                                        |
|---------------------|----------------------------------------------------------------|
| `record.json`       | Raw output from `query_ncbi` (NCBI protein search for PETase)  |
| `test_retrieval.py` | Test asserting `record.json` is valid JSON with a real accession |
| `README.md`         | This file — reproduction instructions                          |
| `report.md`         | Report of what passed and what was explicitly not claimed      |
| `requirements.txt`  | Dependencies (none required beyond Python 3 stdlib)            |

## Reproduction Commands

### Step 1 — Retrieve a real PETase protein accession

Call the `query_ncbi` tool with:

```
query_ncbi(
    database="protein",
    action="search",
    query="PETase",
    limit=1
)
```

The raw tool output is saved verbatim as `record.json`.

### Step 2 — Run the validation test

```bash
python test_retrieval.py
```

Expected output (exit code 0):

```
PASS: record.json is valid JSON and contains a real NCBI protein accession.
  accession       : D4Q9N1
  accessionversion: D4Q9N1.2
  organism        : Thermobifida alba
  source          : https://www.ncbi.nlm.nih.gov/protein/?term=PETase
```

### Step 3 — Inspect artifacts

- `record.json` — the persisted raw retrieval output.
- `test_retrieval.py` — the test source.
- `report.md` — summary of results and explicit non-claims.

## Dependencies

No third-party packages are required. The test uses only the Python 3 standard
library (`json`, `os`, `re`, `sys`). See `requirements.txt`.